# 0415164 平台切换整改实施包

将本目录内容放到仓库 `docs/platform-rebind-fix/`，然后把 `04_codex_task.txt` 的文字交给 Codex。

## 文件

| 文件 | 用途 |
|---|---|
| `01_detailed_fix_plan.md` | 详细整改设计：R1—R10 必修项、R11/R12 补充收口、职责和事务边界、八个改动组 |
| `02_regression_spec.md` | 75 个逻辑回归场景的阅读版，含前置、动作、期望、外写次数和证据 |
| `03_regression_cases.json` | 同源追踪清单，全部 not_run；不是现有 batch-matrix-v2 输入文件 |
| `04_codex_task.txt` | 简短执行入口 |
| `05_acceptance_report_template.md` | Codex 完成后填写的分层验收报告模板 |
| `evidence/` | 固定基线审查及历史探针/CI 摘要，仅作为问题来源 |
| `package_validation.json` | 本实施包的文件和内容一致性检查，不是业务测试结果 |

## 读法与边界

基线为 `041516434bb34272c3d3b364cb001af2568ef7a4`。当前工作树若更新，先核对后复用，不回退新修改。

实施按 B0→B7 进行，R1 的入口开放必须和 R5 的限域校验、R6 的状态/事务保护一起生效。默认不修改 OLS、不执行机器人、不自动推送。

历史 `isolated_results.json` 的 reproduced=true 表示审查探针复现了旧缺陷，不能用于宣称整改验收通过。正式测试必须使用实际仓库类，并在项目支持的 Python 环境重新执行。

本包只提供方案与待执行验收规范，没有修改远端仓库，没有运行新的 Brain/Qwen/OLS/Gateway 测试。

`evidence/original_review_bundle.zip` 保留上一份审查包的完整探针和来源摘录；它们只用于追溯旧缺陷，不替代正式仓库测试。`evidence/implementation_review.md` 原文所提到的探针文件可在该审查包中查到。
