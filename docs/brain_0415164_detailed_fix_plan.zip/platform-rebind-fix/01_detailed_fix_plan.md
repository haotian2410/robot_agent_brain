# robot_agent_brain：0415164 平台装配与状态一致性详细整改方案

**用途：交给 Codex 分阶段实施；本文是修改设计，不是已完成的修改或验收报告。**  
**固定审查基线：** `041516434bb34272c3d3b364cb001af2568ef7a4`  
**仓库：** `haotian2410/robot_agent_brain`  
**编制日期：** 2026-11-07  
**实施范围：** Brain；涉及 Gateway／WebEditor 的协议依赖必须显式列出，不得假定另一个仓库已经支持。  
**支持环境：** 使用项目声明的 Python 3.11、3.12 进行正式测试。

---

## 0. 阅读顺序、证据范围和交付要求

先阅读本文，再阅读 `02_regression_spec.md` 与 `03_regression_cases.json`。`04_codex_task.txt` 是执行入口，`05_acceptance_report_template.md` 是最终报告模板。

事实依据为随包保留的 `evidence/implementation_review.md`、`evidence/isolated_results.json` 和 `evidence/ci_evidence_summary.txt`。审查中的 R1—R10、RB01—RB10、S01—S12 编号沿用，不重新给历史证据赋予不同含义。

必须区分以下三件事：

- 审查中的十个探针是**抽取方法体＋合成对象／平台替身**的缺陷复现，实际探针环境为 Python 3.13.5；不是全仓测试，更不是受支持环境验收。
- R8 首轮 manifest 覆盖属于源码调用链确认，未在该审查中完成服务级复现。实施时先补真实类测试，不得把它写成已完成真实浏览器复现。
- 本方案后文的新接口、错误详情、事务步骤和测试预期是**建议实现的设计**，不是声称当前仓库已存在。优先复用已有等价组件，避免制造第二套状态和提交框架。

历史 CI 记录为 `21 failed, 866 passed, 10 skipped`；其中 8 项与缺少 openpyxl 有关，13 项依赖仓库外资源。它是固定提交的历史证据，不是当前环境的测试结果，也不等于 21 个生产逻辑缺陷。

### 0.1 开始实施前

1. 记录 `git status --short`、当前 SHA、当前分支，与固定基线做 diff；工作树若已包含后续修复，应验证后复用，不能覆盖新代码。
2. 不执行 `git reset --hard`、`git clean -fd`，不删除／覆盖本地未跟踪配置、资料和 IDE 文件。
3. 记录现有公开接口、Scene 序列化、Session 持久化和 Gateway 协议版本；默认保持兼容。
4. 先运行可执行的基线测试，保存失败清单；不能把基线失败直接计为新改动回归，也不能当作已解决。
5. 可以按本文的改动组组织补丁；是否建立 Git commit 依用户或仓库授权执行。**不得自动推送远端。**

### 0.2 本轮不做

不接入或调用 Control、IK、MuJoCo、真实机械臂执行；不训练／更换模型；不修改生产 OLS 资产包；不重写整个任务理解框架；不把双臂换装扩展为本轮新功能；不重新改造已经独立工作的批量矩阵架构。

---

## 1. 总体目标与整改映射

**目标不是“让切换请求不报错”，而是让允许的切换一次完成、无关状态不变、非法切换在写入前被拒绝、未知提交结果可以安全恢复。**

| 任务 | 优先级 | 已知问题／范围 | 主要落点 | 验收核心 |
|---|---|---|---|---|
| R1 | P0 | Web 的 agent_owned 阻断当前任务换装；浏览器 rebind 预检又按普通编辑拒绝 | service、session、application | 自身合法租约可换装，其他任务不能借此越权 |
| R2 | P0 | camera-only／gripper-only 重写机械臂 RobotDriver | assembly adapter | 非目标机械臂状态完整保持 |
| R3 | P0 | 换臂保留夹爪却保留旧挂接点 | assembly adapter、attachment validator | 保留资产，重新校验挂接 |
| R4 | P1，但须在开放切换前完成 | 新对象用旧索引；底座使用 max(ID)+1 复用退役 ID | adapter、allocator、session | 候选索引一致、历史 ID 永不复用 |
| R5 | P0 | platform_rebind 对普通对象／桌面等过度豁免 | shared rebind validator | 仅批准的对象／字段允许变化 |
| R6 | P0 | 持物／未知状态保护不一致；TypeError 导致重复写 | session、scene platform port、gateway | 安全状态一致；每次意图最多一次修改提交 |
| R7 | P1 | UR5e／任意 Profile 的简化判定 | profile registry、application、session | 按实际装配匹配能力，不把展示当执行 |
| R8 | P1，但与事务实现一并完成 | 首轮先提交默认平台，再换装，最终 manifest 被旧模板覆盖 | application、bootstrap、original store | 首轮最终候选一次提交、manifest 正确 |
| R9 | P1 | 全句第一个方位覆盖多个 add 操作 | task_understanding | 正确模型语义不被归一化改坏 |
| R10 | 发布门槛 | 核心测试依赖开发机路径，CI、wheel 未完成 | tests、CI、packaging | 干净 checkout 可重复验收 |
| R11 | P1，补充收口 | live 缺省协议仍可落入兼容路径 | qwen_http、wire schema、replay adapter | live 强制 v3.1，兼容只在显式 replay 入口 |
| R12 | P1，边界说明／设计补强 | 单臂限制、相机目标范围、目录版本和公共接口兼容 | contracts、capabilities、文档 | 明确边界，不扩大用户请求 |

R11 来自审查“补充观察”，不计入十项探针；R12 是本轮实现必须明确的边界，不宣称已全部被审查复现。

---

## 2. 不得破坏的系统不变量

| 编号 | 不变量 |
|---|---|
| I01 | Qwen 仅输出语义和目录内的资产选择，不分配实例 ID、不提供连接关节猜测、不生成装配坐标、租约或授权。 |
| I02 | OLS 可展示、Profile 可规划、运行状态已确认、Control 可执行是不同事实。 |
| I03 | 普通场景编辑的资产替换／平台不可变保护继续有效；不能通过 change_kind 绕过。 |
| I04 | 相机单独切换不改变机械臂任何部署或当前关节状态；夹爪单独切换不重写机械臂 RobotDriver。 |
| I05 | 换臂时保留的附件必须通过新挂接校验；不能把旧关节名原样当作有效。 |
| I06 | 新场景对象使用统一单调分配器，删除不回收，重启不降低分配高水位。 |
| I07 | 当前任务必须证明自己持有有效租约；不能临时解锁或改 phase 为 setup 来获得写权限。 |
| I08 | 有未完成执行、持物、显式未知运行状态或恢复冲突时，不能进行有副作用的换装。 |
| I09 | 一次 Agent 换装意图最多发送一次修改请求；响应丢失后只做同一事务的证据查询。 |
| I10 | 提交前拒绝不得改变场景、版本、Profile／装配绑定或 original；允许记录诊断，ID 已预留则允许留下空洞。 |
| I11 | 提交结果未知不得声称场景未变，也不得声称成功；进入 unknown／quarantine，阻断新写入与命令派发。 |
| I12 | 确认提交前不清空旧本地绑定；确认提交后场景、manifest、装配身份、revision 和缓存失效须一致。 |
| I13 | original 只按既有冻结规则创建一次，平台切换不能覆盖已存在的 original。 |
| I14 | 合法且明确的多操作方位语义不得被全句关键词覆盖。 |
| I15 | 无实际变化的有效请求默认 no-op：不写场景、不加版本、不清空运行状态或规划绑定。 |
| I16 | 所有生产侧返回保持 executed=false；“装配已切换”不得写成“机器人已执行”。 |

**特别说明：**“失败无副作用”针对可确认的预提交拒绝或确认未提交；如果外部可能已提交而 ACK 丢失，必须报告未知，不能伪造回滚。ID 预留、事务日志、失败诊断与场景业务状态分别判断。

---

## 3. 收敛后的职责与内部契约

### 3.1 保留现有框架，增加少量共用能力

```text
自然语言／浏览器变更意图
    → 语义和资产选择校验
    → 可信任务上下文＋状态前置校验
    → 只读构造最终候选与精确 diff
    → 装配／引用／允许变更范围／能力校验
    → 提交或采用已有外部快照（两条明确路径）
    → 回执与 live digest 确认
    → 提交本地场景、绑定、manifest、revision
    → 持久化证据，正常解锁或保持隔离
```

建议文件位置如下；已有等价组件则复用，不要求按名称新建所有文件。

| 位置 | 职责 |
|---|---|
| `contracts/platform_rebind.py`（建议新增） | 内部请求、可信上下文、计划、结果的数据结构；不是直接让模型填写的新协议 |
| `scene/platform_rebind_validator.py`（建议新增） | before／candidate／请求／可信目录的限域变更校验 |
| `adapters/ols_robot_assembly.py`（现有） | OLS 装配数据解析、纯候选构造；不做外部提交、不决定任务授权 |
| `session/brain_session.py`（现有） | 状态机与统一换装事务入口；可抽取 coordinator，但不可维护平行 Session |
| `web/service.py`（现有） | 身份、任务所有权和租约上下文注入；保持 Web 与 Session 校验一致 |
| `web/gateway.py`、`ports/scene_platform.py`（现有） | 明确平台提交接口、能力检查、事务回执、未知结果核验 |
| `application.py`（现有） | 首轮准备、调用编排、original 冻结和最终报告；不再二次覆盖 manifest |
| Profile 相关现有模块 | 装配到 Profile 的唯一匹配与能力理由 |

### 3.2 内部对象需要表达什么

以下为逻辑字段清单，不是可以直接复制编译的实现代码。具体类型沿用仓库已有 SceneId、SceneSnapshot、RobotSetup 等。

**RebindContext（可信内部上下文）**

- 来源：当前 Agent 任务、浏览器手工快照同步、明确的本地编辑器入口。
- session／browser／task 身份、当前事务的 owner；有效 lease 的内部引用与 generation。
- expected scene_id／scene_version／scene_sub_version／digest。
- catalog／assembly revision、会话 checkpoint revision。
- 运行模式：纯场景编辑，或存在外部机器人运行状态的会话。

上下文由 service／session 构造，不能由 Qwen、raw JSON 中的 `authorized=true` 或请求任意布尔字段赋权。完整 lease token 不写入日志。

**PlatformRebindPlan（提交前计划）**

- 用户请求的各资产，解析后的精确资产 key。
- 根据实际前后身份计算出的 changed_roles。
- before 身份和摘要；candidate scene。
- 各对象角色、保留／新增／移除 ID、分配授权记录。
- 预计且实际的 component／field diff。
- 重挂附件的连接关系及元数据来源。
- 最终 platform_object_ids、能力匹配结果、需要失效的缓存／绑定。
- noop、validation evidence、catalog revision。

计划不含“已提交”结论；不能在 adapter 返回候选时增加 Session revision。

**PlatformRebindResult（确认后事实）**

- no-op、confirmed committed、confirmed rejected、unknown 四类内部结果。
- 来源是 Brain 提交还是对浏览器已完成快照的采用。
- transaction_id、前后身份／digest、确认依据。
- 最终装配身份、manifest、Profile／能力理由、状态就绪程度。

公开 response 仍保持已有字段兼容；新增内部字段先写诊断，确需公开再核对前端是否容忍。

### 3.3 三个核心函数的职责边界

建议形成等价于下列接口的内部边界：

```text
prepare_rebind(before, request, catalog_snapshot, allocated_ids)
    → 不修改 before 的候选计划

validate_rebind(before, candidate, request, context, catalog_snapshot)
    → 被批准的精确差异与验证证据，或明确拒绝

commit_or_adopt_rebind(plan, context)
    → 对外提交一次，或验证并采用已提交快照；随后更新本地状态
```

adapter 不能负责自动选择某个 Profile，validator 不能修正未经请求的对象，Web 不能靠先清空 Session 再重载绕过一致性检查。

---

## 4. R1：统一 Web／Session 切换权限和入口

**依据：审查 R1；源码 S02、S03。依赖：R5 限域校验器和 R6 状态／事务约束必须与入口开放一并生效。**

### 4.1 当前 Agent 任务发起的切换

修改 `AgentService.execute()`、`BrainApplication.handle/_handle()` 与 Session 调用之间的上下文传递，使用可选且显式的内部参数，不通过全局临时变量表示授权。

保持 `session_phase=agent_owned`，不得为了通过 gate 改回 setup。Session 判断：

1. 当前任务是否与 service 分配的活动 owner 相同。
2. session／browser 是否与 lease 绑定一致。
3. lease 是否有效、未过期／未被隔离，快照是否与 expected identity 一致。
4. 是否无其他任务和外部执行冲突。
5. R6 的状态检查是否通过。

以上成立，允许**当前 owner 自身**构造并提交平台变更；缺少上下文、伪造任务 ID、过期租约或另一个任务调用必须拒绝。直接 Python API 不得因为调用方只传 `origin="agent"` 就被信任。

正常场景编辑和机器人计划也继续走原有 gate；不能把所有 agent_owned 调用都放开。

### 4.2 浏览器手工变更平台后的快照同步

保留 `StartTask.change_kind` 的公开兼容，但把它当作“请求使用何种验证规则”，不是授权。

`validate_scene()` 必须接收到变更类别及可信来源上下文。普通场景编辑仍使用原有不可变规则；平台重绑定必须调用 R5 同一个 validator。

要区分两个实际场景：

- **浏览器只是提出变更、尚未提交：** 通过当前部署已支持的 Gateway 接口提交候选，复用事务确认，不创建另一套无版本接口。
- **浏览器已经提交，Brain 本轮只是同步：** 根据此前 setup／无活跃任务事实、身份、版本、允许的 diff、Gateway live readback 及可用回执验证，再调用 adopt；不要再次 load_scene 提交同一个变化。记录这是 observed/adopted，不伪称 Brain 发起了原子写入。

不要在不知道 Gateway 当前能力的情况下凭空增加跨仓库 API。若已部署协议缺少必要证据，应明确返回升级／能力不足，并列出另一仓库需要配合的字段。

### 4.3 时序与拒绝语义

预校验必须先于创建会导致浏览器锁定的副作用。工作线程中仍需要重复检查租约保护下的当前状态，防止预检后现场改变。

若浏览器现场已被改成非法候选，Brain 拒绝采用时不能说“浏览器场景未变化”，也不能保持已同步的假象；应保留旧本地快照、标记不一致并进入现有恢复流程。没有确认恢复回执，不得自动写回旧场景。

### 4.4 验收

已有场景通过真实 `create_http_app/AgentService` 入口＋假 Qwen＋Mock Gateway 完成一次换装；测试不能只调用 adapter。另测 owner 不同、lease 过期、非法 browser／session、活动外部执行、普通 scene_edit 夹带平台变更。

---

## 5. R2：局部更新与真正的 no-op

**依据：审查 R2、RB02；源码 S01。**

### 5.1 按解析后的有效身份判断是否变化

把 `arm_changed = robot_asset is not None` 改为比较当前与目标**精确资产身份**。同义名称归一后指向同一 key 不算更换。

只计算用户请求的部件。省略 robot_asset 表示不换机械臂，不表示重载机械臂元数据。不能借机恢复 OLS 默认值。

如果请求资产均相同、没有有效挂接／配置变更且当前装配已合法，返回 no-op。用户要求“重置姿态”属于独立语义，不可把“换成当前型号”当作 reset。当前没有 reset 协议就明确不支持，不能暗中新增含义。

### 5.2 按角色定义最小修改集合

| 请求 | 可以改动 | 必须保持 |
|---|---|---|
| camera-only | 目标相机的资产资源；依据明确相机契约需要变化的字段 | 机械臂全部组件、所有关节值、夹爪、底座、桌面和普通物体 |
| gripper-only | 目标夹爪资产、夹爪 driver、明确挂接、必要的夹爪局部变换 | 机械臂 RobotDriver 与 Transform、无关相机、桌面和普通物体 |
| arm-only | 机械臂资源／新 driver、声明的装配位姿、必要底座、保留附件重挂 | 普通物体、桌面、灯光、世界固定相机；夹爪资产本身 |
| 组合变更 | 以上允许集合的并集，经过连接一致性检查 | 所有未请求、无必要依赖的对象／字段 |
| no-op | 诊断记录 | scene、version、sub_version、digest、运行状态、Profile、有效命令和 manifest |

camera-only 不得通过重建整个 arm 对象重写其默认 driver；保留对象时使用原有 lossless Scene 表示，避免丢失未知扩展字段或组件。

相机“换外观资源”与“换光学参数”的契约必须在实现报告说明。OLS 没有权威参数时不得猜内参；用户只要求资源切换时优先保留现有 Camera 配置。不得把此建议写成当前 OLS 已具备某些字段。

### 5.3 运行状态与缓存

相机变更仅失效受影响的视觉证据／缓存；不清空机械臂已确认状态。夹爪变更需要失效相关抓取／末端配置，但保留未变机械臂的状态证据；新的夹爪状态不能从旧夹爪复制成“已知”。

换臂后的初始显示关节值可以按协议填充，但必须与真实测量事实分开；`initial_joint_positions_rad` 或库内 `now_joint_positions_rad` 不得独自证明运行状态已知。

### 5.4 验收

fixture 必须包含非零 now、与 now 不同的 initial，以及可合法保留的扩展字段。比较整段非目标对象／组件，而不是仅断言 Transform。

---

## 6. R3：换臂后重新绑定所有受影响附件

**依据：审查 R3、RB03；源码 S01、S06。**

### 6.1 挂接计划

从 before 的真实装配图收集当前机械臂直接和间接相关附件。对用户未更换的夹爪，保留资产 key 和实例 ID，但重新检查新臂连接点、父 link、子 link、连接类型和挂接变换。

同样检查实际存在的腕部相机等附件；世界固定相机不得因为换臂而移动。没有明确元数据证明属于机械臂附件的普通物体，不纳入自动重挂集合。

### 6.2 连接点选择

只能使用已声明的 OLS／配置连接关系和可验证的 joint/link inventory。若唯一可用连接对存在，确定性选择并记录依据；多个候选需使用显式兼容映射或澄清，不能默认 `[0]`。

禁止缺失字段时补空字符串、零位姿或单位四元数来伪造有效连接。只有契约明确把某个值定义为合法默认时才可采用，并记录来源。

### 6.3 一致性校验

至少校验：

- Transform.parent 和 RobotAttachment.parent_object_id 指向正确父实例；两种表示应符合项目约定。
- parent_joint、parent_link 属于新机械臂；child_link 属于目标／保留夹爪。
- 引用不悬空、不自引用、无父链环。
- 固定连接变换来自权威连接契约；四元数有限、有效，单位／坐标系明确。
- 删除底座或替换父实例后，所有允许保留的引用仍然有效。

复用 `ComponentReferenceRegistry` 做存在性校验，再补装配语义校验；“被引用对象存在”不能代替 joint/link 匹配。

若当前 Brain 无法确定 attachment 的世界位姿，保留平台拥有该位姿的约定，不用父对象位姿代替，更不能调用 IK 来补装配信息。

### 6.4 失败处理

不兼容／缺失连接信息是提交前失败，保持原场景。多候选且用户能消歧时澄清；确定不兼容时返回明确原因，不无限调用 Qwen 修补。

---

## 7. R4：候选场景索引与单调 ID 分配

**依据：审查 R4a/R4b、RB04/RB05；源码 S01、S02、S07。**

### 7.1 不混用新对象和旧索引

在处理新增对象之前，先从 before 收集旧夹爪、底座、相机角色。此后所有候选访问只能来自统一的候选对象映射或重新构造的 candidate index。

禁止 `for id in new_objects` 后用 `SceneIndex(before)` 查询新增 ID。避免散落多个随时可能失效的 SceneIndex。

### 7.2 统一分配器

把 Session 的历史高水位、seen／retired IDs 与 Gateway 分配授权接入同一个分配接口。adapter 只消费已预留的 ID 或显式 allocator，不自行计算 `max(current_objects)+1`。

夹爪、底座以及同一事务内其他必要新增部件共用分配器；每个新 ID 只能分配给一个对象。保留原实例时使用原 ID，删除后再次创建必须得到新 ID。

仅有 `next_object_id` 一个值时，必须在本地计划中推进游标并验证所有新增对象；不能只在夹爪分支使用而底座分支忽略。

### 7.3 预留与失败

允许 ID 预留后验证失败造成间隙；不得为了“回滚计数”而复用已预留或已发布的 ID。区分已分配 ID、已见过实例 ID、已退役实例 ID，不能用简单 `< next_id` 规则误拒绝本事务合法预留的 ID。

分配高水位必须按现有持久化／Gateway 约定保存，重启不下降。使用 `scene_id_bits` 对应范围，接近上限时返回明确耗尽错误，不溢出、不回绕；若当前协议没有“最后一个 ID 已分配”的表示方式，应在边界前明确拒绝，不发明与 Gateway 不兼容的 sentinel。

### 7.4 核心回归

无夹爪新增；底座 6 删除后 highwater=20 再创建；UR5e→无底座平台→UR5e；同轮新增夹爪和底座；失败后再次分配；Session 重启；浏览器与 Agent 分配请求并发；uint32 边界。

---

## 8. R5：精确限制 platform_rebind 的允许变更范围

**依据：审查 R5、RB06；源码 S02、S06。必须在解除 R1 阻断之前启用。**

### 8.1 可信依据

validator 输入包括 before、candidate、用户明确的切换意图、可信 catalog snapshot、before 中已确认的平台角色、分配记录及上下文。

不能从 candidate 自报的 Semantic.category 推导“这个普通物体现在属于平台，所以可以改”；角色来源必须是 before 与可信目录。`change_kind` 也不能作为免检凭证。

### 8.2 按对象和字段比较

对普通物体、桌面、灯光、非目标相机和其他不相关对象，要求完整语义内容不变，包含未识别但原样保存的扩展组件。不要靠删除字段、先规范化 candidate 再比对来掩盖不允许的变动。

可采用规范化 JSON digest 排除字典键顺序差异，但数组／组件顺序如何处理应与现有 lossless Scene 契约一致，不擅自定义另一套摘要。

对目标机械臂／夹爪／相机，逐字段允许预定变更，并与目标元数据／装配计划核对。底座增删必须由目标臂装配要求推导，不能允许任意 support 类对象删除。

同实例 ID 的 MetadataRef 变化仅限已确认的目标平台角色。普通对象原 ID 替换继续拒绝。新对象必须具备分配依据；旧对象删除必须在 approved removals 中。

### 8.3 公共验证器贯穿各入口

Agent 构造候选也要验证，不能“内部生成就相信”；浏览器候选也用同一验证器，不能“来自当前页面就相信”。

不要从完整 candidate 自动推导一个包含所有非法变动的“请求”再据此验证；浏览器若缺显式 intent，只能从受限平台资产替换模式推导请求，剩余差异仍需保持不变。无法安全推导时明确拒绝或要求协议补充。

### 8.4 回归

合法换装中夹带：苹果原 ID 换香蕉、普通物体移动／删除、桌面位移／缩放、灯光改变、非目标相机改参、未请求的关节限位修改、非法 RobotAttachment、伪造平台 manifest。均在 Brain 发出新修改请求前拒绝。

对已经在浏览器侧发生的非法变动，拒绝采用并标记不同步；此时不可把“没有额外写入”描述成“现场未变”。

---

## 9. R6：统一空闲保护、单次写入与恢复

**依据：审查 R6、RB07/RB08；源码 S02、S04。**

### 9.1 共用前置检查

所有入口复用同一个安全检查，不分别手写不一致条件。至少覆盖：

- session 未关闭、未暂停到禁止修改的状态。
- sync_state 已同步，无 quarantine、恢复冲突或未决提交。
- 无 pending_execution_request、已派发未确认动作或有效执行占用。
- 无 holding_object；已有逐臂运行状态中无持物、未知或非空闲状态。
- actor 所有权有效，与当前会话、浏览器、租约一致。

**编辑器无机器人运行证据与明确的机器人状态未知要分开。** 全新纯展示／编辑会话没有 Control 接入、没有执行历史且没有持物／pending 证据时，可依据明确的 editor-only 配置进行装配；这不能使它变成可执行会话。存在 `state_known=false`、历史执行未确认或外部机器人状态来源时必须保守阻断，不能用“这是场景编辑”跳过。

若暂时无法可靠区分，默认拒绝有运行风险的切换，并明确缺少的状态证据。不要通过清空 holding_object 或 arm_states 让 gate 通过。

### 9.2 删除 TypeError 重写兜底

统一 `ScenePlatformPort.load_scene(scene, *, change_kind=...)` 的接口，更新 LocalScenePlatform、Gateway 和测试替身。在 adapter 构造／能力协商阶段决定兼容，不在调用后通过捕获 TypeError 再试一次。

不能把 platform_rebind 降级为 scene_edit。目标 Gateway 未声明该操作能力时，在写入前返回升级／能力不足，不等到网络写入失败才兜底。

### 9.3 事务顺序

1. 持有有效上下文，检查 before 身份与摘要。
2. 纯构造并验证 candidate；预先完成能完成的 manifest、能力匹配和本地提交准备。
3. 持久化 prepared 事务记录：transaction ID、expected identity、candidate digest、catalog revision、允许变更清单。
4. **只发送一次**修改请求；记录 write_attempted 的真实阶段。
5. 正常 ACK 时核对事务、身份、版本、digest、拒绝对象列表及 live readback。
6. ACK 丢失／HTTP 超时／写入中内部异常时，只查询同一事务与现场。
7. 确认为 committed 才更新本地场景、绑定、manifest、revision，并持久化 checkpoint／publication。
8. 确认为 rejected 且现场仍是 before，保持原业务状态并结束事务。
9. 证据不足则 unknown／quarantine；保留 before、candidate 和 journal，禁止后续写入／派发。

保持现有锁、队列、PublicationStore 和 Gateway journal；不要新建第二套独立状态库。特别注意不要重复获取同一不可重入 Session 锁导致死锁。

### 9.4 本地提交与解锁

外部提交确认但 checkpoint 写失败，不能报告“未改变场景”，也不能正常解锁后允许继续操作；必须保留外部提交事实并转入恢复。

不要提前清除旧命令和 Profile；但一旦结果 unknown，所有旧命令均不可派发，直到现场核验完成。恢复必须根据同一事务更新／失效相关绑定，不能自动重新加载旧场景。

### 9.5 验收

用 MockTransport 统计修改请求次数。load 内部抛 TypeError、写入后超时、ACK 丢失、回执身份错误、live digest 不匹配、确认拒绝、checkpoint 失败和解锁失败分别测；不能仅断言“抛了异常”。

---

## 10. R7：能力与 Profile 按实际装配匹配

**依据：审查 R7、RB09；源码 S02。**

### 10.1 取消两种捷径

删除“只要 robot_asset=ur5e_arm 且任意 Profile 存在就 supported”的逻辑；也不能以 Profile ID 与资产名字相同就直接认为匹配。

将 Application 导入、Session 恢复、平台切换、浏览器采用和对外 capabilities 的判断收敛到同一个服务／函数，避免同一场景不同入口给出不同能力结论。

### 10.2 匹配证据

按现有 Profile 契约检查机器人资源身份、RobotDriver 部署配置、joint 序列与限位、末端工具／夹爪、连接关系、TCP／受控链以及已注册规划能力。实例 ID 变化通过经过验证的映射处理，不靠名字猜。

无匹配：展示／场景查询仍可合法工作，但机器人规划返回 capability_unsupported。

多个匹配：需要显式配置唯一选择或清晰诊断，不能任取第一个。

唯一完整匹配：建立新 setup／profile_object_map；运行状态 readiness 单独判断。元数据默认关节值不等于外部状态已确认。

### 10.3 保留旧 UR5e 的方式

若必须保留内置单臂 UR5e 路径，把它包装为明确的 legacy deployment descriptor／内置 Profile 适配入口：只适用于原先已验证的资源、driver、末端和场景条件。

不得扩大成“只要配置字符串写 ur5e，任意夹爪／任意 driver 都支持”。正常既有单臂功能需专门回归，不能为了收紧新装配把原功能全部变成 unsupported。

### 10.4 能力分层与公开兼容

内部至少区分：asset display、planning profile compatibility、runtime state readiness、control availability。公开 `execution_capability` 的历史语义应先核对客户端，再用兼容映射导出；必要的新 reason／matched_profile 先放诊断。

本轮任何能力判定都不能开启 Control，也不能把“可规划”描述成“已执行”。新的装配若不支持，报告“装配切换成功，规划能力未注册”，不要把一次成功的展示变更整体误报成场景提交失败。

### 10.5 缓存与恢复

只在确认换装后失效依赖旧装配的已导出计划、绑定及视觉／工具缓存。相机-only 保留不相关机械臂状态；恢复已确认场景后重新核对能力，不盲信持久化的 supported 字符串。

---

## 11. R8：首轮创建与换装构成一个最终候选

**依据：审查 R8；源码 S05。此项先补服务级回归，再修改。**

### 11.1 首轮场景不存在

改造 `_handle()` 的 robot_asset_switch bootstrap：

```text
读取默认模板为纯内存基线
→ 校验请求资产／挂接／所需元数据
→ 在内存构造最终目标装配
→ 统一分配场景及对象身份
→ 最终 manifest 和能力预检
→ 一次 load_scene 提交最终候选
→ 确认后初始化 Session、冻结 original
```

不要先 `initialize_scene(default_template)` 对外提交，再单独换装；第二步失败会遗留未请求的默认平台。

对真正已经上传并确认的空 Scene，保持原有“用户上传场景”语义；不能为了通过 bootstrap 测试私自将它替换成默认模板。使用已有的明确 bootstrap-placeholder 判定。

### 11.2 版本规则

- 新 Scene：新 scene_id，scene_version=1，scene_sub_version=0；属于初次创建。
- 已有 Scene 的有效平台切换：scene_id 和 scene_version 保持，scene_sub_version 恰好 +1。
- no-op：上述所有身份及 digest 不变。
- 失败且确认未提交：保持 before。
- 未知：不编造最终版本，引用事务证据。

建议 adapter 不再自行分配版本，由统一 coordinator 确定创建还是重绑定，避免首轮最终候选错误携带 sub_version=1。

### 11.3 最终 manifest

从最终确认的 candidate 与可信角色生成一次 manifest。禁止 `if report.scene_created` 再把模板所有对象 ID 覆盖回去。

manifest 应只包含平台对象，不包括因测试 fixture 或模板携带的普通任务物体；删除底座 ID 必须消失，新增部件 ID 必须出现，所有 ID 存在于最终 Scene。

### 11.4 original 与恢复

已存在 original 永不覆盖。首轮生成路径没有任何已确认历史快照时，按既有规则冻结**最终确认的生成场景**，中间默认模板不发布、不冻结。

上传 original 已存在时必须保持上传版本，即使后续平台切换成功。任何恢复／从 original 派生新场景后，装配身份和能力需要根据恢复后的实际 Scene 重新匹配，不能沿用被替换分支的绑定。

### 11.5 验收

首句换到无底座平台，随后查询和新增都成功；original、manifest、计数器一致。首轮未知资产、连接不兼容或必要元数据缺失时零场景提交；首轮 ACK 丢失按 R6 恢复，不重新 bootstrap。

---

## 12. R9：停止全句方位广播，保持语义不变

**依据：审查 R9、RB10；源码 S09。**

### 12.1 必须保留的正确行为

普通物体参照保护继续保留：`reference=apple` 的 right_of 不能变成 on apple，也不能重定向桌面。桌面约定可以填充真正未限定的裸 add 默认支撑面，但不代表所有相对位置都是桌面区域。

### 12.2 修改策略

1. 模型已提供合法、明确的 placement_region／placement_hint：不使用整句话第一个关键词覆盖。
2. 多操作输出各自有合法不同区域：原样保持每个操作的区域。
3. 裸 add 未指定位置且没有对象相对语义：按明确桌面运行契约填充默认支撑面；不新增 table 实体。
4. 需要把别名转换成规范枚举时，只转换该字段的表达，不从全句推断覆盖其他操作。
5. 某操作位置缺失，用户原句却包含多个不同位置：优先让模型重新输出正确结构或返回明确模型输出错误；没有可靠的操作—原文 span 对应时，不猜、不广播。
6. 仅当已有协议明确提供可靠 span 或操作子句时，才可做受限的逐操作修复。不要为修这个 bug 再引入一套中文解析器，也不要求本轮强行新增 span 协议。

**区分模型漏字段与用户缺信息：** 用户明确说了“苹果右边”，模型漏 reference，属于模型协议问题；用户只说“最远”而没有参照，才应向用户澄清。不能用澄清掩盖 Python 改坏或模型漏填。

### 12.3 回归

左上／右下、反向排列、逗号／然后、同类物体不同角落、中心＋角落、桌面区域＋普通物体 near、已有合法输出重复规范化。要求幂等：normalize(normalize(x))=normalize(x)，不改数量、对象、操作顺序或资产选择。

---

## 13. R10：测试分层、干净 CI 和 wheel

**依据：审查 R10 与固定提交 CI 摘要；源码 S10、S12。**

### 13.1 基础 fixture 不得依赖开发机

在 tests 下提交最小合法 metadata，或用 tmp_path 生成；必须通过真实 `SceneConfig`、真实 adapter、真实 Session 和当前公共解析器，不以 `model_construct`／抽取方法替身跳过被测契约。

外部服务可以 mock，核心业务类不能用过度简化替身代替。审查 probe 可用于理解故障，但其“reproduced=true”不是修复后的测试通过条件。

最小 fixture 至少包括：带底座 arm A、不带底座 arm B、不同连接点、两种夹爪、两个相机、平台桌面、普通物体、非零 now 状态、有效 profile、无关 profile。测试用名字和 ID 明确标注 synthetic，不能当作 OLS 生产事实。

### 13.2 建议新增或扩展的测试文件

- `test_platform_rebind_service_flow.py`：真实 Web handler／AgentService 到 Session 的路径。
- `test_platform_rebind_validation.py`：允许 diff 与夹带非法改动。
- `test_platform_rebind_transaction.py`：单次提交、ACK／live／checkpoint／unlock 失败。
- `test_ols_robot_assembly_unit.py`：只依赖最小 metadata 的组件和挂接回归。
- `test_platform_rebind_identity.py`：ID 高水位、往返切换、first-turn manifest。
- `test_platform_capability_binding.py`：Profile 匹配与能力分层。
- 原 `test_task_understanding_clean_v3.py`、`test_asset_catalog_v31.py`：方向、live 协议边界。

名字是建议；已有文件可扩展，但每个用例要能映射到 `03_regression_cases.json` 的 ID。

### 13.3 三层测试，不混报

**L1 单元／模型契约：** 不需要 Qwen、OLS 服务、真实包或浏览器。使用仓库实际业务类。

**L2 服务集成：** 真实 AgentService、Session、Gateway adapter，MockTransport 模拟网络并校验请求计数、租约、版本与回执。不能绕过 worker phase 设置。

**L3 真实联调：** Qwen→Brain→Gateway→浏览器＋明确版本的 OLS 测试实例。必须记录原始输出、场景 diff、提交回执和最终读回。截图是补充证据，不是唯一判定。

外部资源缺失的测试标为 not_run／blocked_environment，不算通过。真实装配目录测试不要写死 `/home/cscvlab/...`；使用显式测试配置或环境变量。仅真实集成依赖可以跳过，核心单元回归不得全部 skip。

### 13.4 CI 修改

将测试安装命令改为项目所需 extras：

```bash
python -m pip install -e '.[dev,web,batch]'
pytest -ra brain_tests/
```

将真实外部集成测试标记并按作业分开执行，新增 marker 名称需在配置注册。默认核心作业不以未提交 `var/` 缓存或个人路径为前提；缺失资源不能令核心契约测试跳过。

Python 3.11、3.12 都需要完整结果。建议矩阵 fail-fast=false，以便一边失败时仍得到另一边的有效证据；不能把 cancelled 写成 passed。

### 13.5 wheel 验证

在对应 Python 环境构建，使用独立虚拟环境、离开源码目录并清除 PYTHONPATH 安装测试。下面是实施后命令示例，不是本包已经执行的结果：

```bash
REPO="$(pwd)"
python -m pip wheel --wheel-dir wheelhouse '.[web,batch]'
python -m venv /tmp/brain-wheel-env-0415164
/tmp/brain-wheel-env-0415164/bin/python -m pip install \
  --no-index --find-links "$REPO/wheelhouse" 'robot-agent-brain[web,batch]'
(cd /tmp && env -u PYTHONPATH /tmp/brain-wheel-env-0415164/bin/python \
  -c 'import robot_agent_brain; from robot_agent_brain.models.prompts import TASK_UNDERSTANDING_PROMPT; assert TASK_UNDERSTANDING_PROMPT')
(cd /tmp && env -u PYTHONPATH /tmp/brain-wheel-env-0415164/bin/python \
  "$REPO/scripts/wheel_smoke.py")
```

临时 venv 已存在时使用新目录，不清理用户目录。若 smoke 脚本有额外 fixture 要求，应按现有契约补齐并报告；不得仅以 editable install 成功替代正式 wheel 通过。

---

## 14. R11／R12：补充协议与能力边界收口

### 14.1 live v3.1 与 replay 显式分离（R11）

审查指出：显式 v2/v3 scene_edit 已加强拒绝，但缺省协议仍有兼容早退。这一项不在十个复现探针中，先补实际 provider 测试。

有当前目录的 live 调用必须使用唯一预期版本，并在服务端解析校验，不仅依赖模型服务的结构化解码。缺少 protocol_version、旧版本或未知版本均不能绕过 asset choice 校验。

有效目录快照的确定要统一：请求携带快照或 provider 使用缓存快照时，Prompt、payload 与校验必须使用同一个有效快照；不能请求实际上附了目录，解析却因为另一个字段为空进入 replay 分支。

旧录制数据由显式 replay adapter 转成 canonical 模型，兼容权限取自入口，不取自模型自己返回的版本。保留历史 replay 功能，不把新 live 约束无差别施加到旧文件。

不得恢复固定 cup→mug 选择。asset_key、名称、可新增状态、实体用途与本轮目录一致性检查保留。

### 14.2 单臂限制（R12）

本轮 adapter 仍按单臂范围实施，双臂换装不属于必须新增功能。双臂输入应在写入前明确拒绝并解释当前装配范围，不能为了让切换通过只修改第一条臂。

已有双臂任务规划／反馈／快照功能必须回归，不能因单臂换装重构被删除或被误认为全系统不支持双臂。

### 14.3 多相机目标范围（R12，设计要求）

用户只提出“换相机”时，优先使用已明确绑定且有效的相机目标；无唯一目标时澄清。不能因为多个相机使用相同资产名称就默认都要更换。若现有产品协议明确规定该操作是批量换相机，必须保留并在请求中显式表达范围，不能在重构中默默变更含义。

目标选择不允许模型猜 scene object ID；实际绑定由已有 scene context／用户选择／resolver 完成。

### 14.4 目录和会话一致性（R12，设计要求）

一次换装使用固定 assembly/catalog snapshot。热更新后，新请求使用新快照，已准备事务不能半途混用新目录。缓存 Session 中的装配 adapter 与应用目录的更新策略必须明确并有测试。

这部分是需要实施时检查的设计边界，不将其描述成审查已证明的另一组生产缺陷。

---

## 15. 错误、诊断与用户回复

### 15.1 对外兼容优先

优先保留既有 error.code，在 `details.reason`、`details.path`、`stage` 中补精确信息；新错误码要登记并更新 UI／batch 映射。以下是建议分类，不声称均已存在：

| 阶段 | 例子／建议 reason | 是否自动重新提交 |
|---|---|---|
| ownership_preflight | owner_mismatch、lease_expired、session_busy | 否 |
| runtime_preflight | holding_object、runtime_unknown、execution_pending | 否 |
| catalog_binding | unknown_asset、catalog_revision_mismatch | 否 |
| assembly_validation | mount_missing、mount_ambiguous、attachment_incompatible | 否 |
| diff_validation | unrequested_object_change、forbidden_component_change | 否 |
| identity_allocation | object_id_space_exhausted、retired_id_reuse | 否 |
| capability_binding | profile_not_registered、profile_ambiguous、deployment_mismatch | 仅展示可独立成功；不执行 |
| external_commit | confirmed_rejected、commit_unknown、receipt_invalid | 否；仅查询证据 |
| checkpoint | checkpoint_write_failed | 否；保留提交事实并恢复 |
| semantic_normalization | missing_model_field、multi_clause_binding_missing | 可按已有策略做有限模型修复，不提交错误候选 |

### 15.2 每次换装至少记录

```text
request_id / task_id / session_id / browser_id（按已有脱敏规则）
origin / owner proof 摘要（不记录完整 lease token）
instruction / raw model output / canonical switch request
catalog_revision / assembly_revision
before identity + digest
requested assets / resolved keys / changed_roles
allocated IDs / retained IDs / removed IDs
attachment rebinding evidence
allowed diff / actual diff / validation failures
candidate identity + digest
transaction_id / write_attempted / receipt / live readback digest
profile match / runtime readiness / control availability
checkpoint result / unlock result / final classification
```

不要只记录 `provider_error`；也不要为了隐藏内部实现把原有诊断 stage 全部丢弃。公开 Web 回包可脱敏，完整本地证据保留。

### 15.3 回复应反映事实

- no-op：已是该装配，场景未改变。
- 展示切换确认成功、Profile 缺失：装配已切换，该装配尚无可用规划 Profile；未执行机械臂动作。
- 预提交拒绝：说明原因，场景未提交修改。
- 提交未知：说明结果待核验、已阻断后续修改，不声称已经回滚。
- 浏览器外部非法改动未被采用：说明 Brain 与现场不一致，需要核验，不说现场未变化。

---

## 16. 建议的八个改动组和依赖

| 组 | 内容 | 关键约束／阶段出口 |
|---|---|---|
| B0 | 核对基线、最小 fixture、把 RB01—RB10 改成真实仓库类的正确行为回归 | 先记录哪些当前失败；不让“缺陷仍出现”成为通过标准 |
| B1 | R5 限域 validator＋R6 状态检查＋Port 接口统一 | 不开放新权限；已有 gate 暂时保持，校验器先就绪 |
| B2 | R2 局部更新／no-op＋R3 重挂＋R4 索引／ID | 纯候选构造测试全部通过；不需要真实服务 |
| B3 | R8 首轮最终候选＋统一 manifest＋事务本地提交 | 单次写入、original／manifest／revision 一致 |
| B4 | R1 Agent／browser 入口联通＋R6 外部失败恢复 | 自身租约允许、越权阻断；必须包含真实 service 路由测试 |
| B5 | R7 Profile／能力统一＋R12 范围和快照边界 | 展示／规划／运行状态／执行不混同，旧单／双臂功能回归 |
| B6 | R9 多子句语义保持＋R11 live/replay 边界 | 不改正确模型输出，不让模型自行选择兼容模式 |
| B7 | R10 干净 CI、wheel、真实联调与报告 | 测试分层报告；没有服务时只写 not_run，不宣称验收结束 |

B1—B4 涉及同一安全链：不得只提交“放开 agent_owned”而遗漏允许 diff、持物、租约和单次提交保护。可以分多个小提交，但对外启用应作为一个完整能力交付。

每组输出修改文件、关键 diff、执行命令、通过／失败／跳过数、未解决问题；所有数据来自真实执行。

---

## 17. 最终验收门槛

本轮完成必须同时满足：

1. 真实仓库类的核心回归在 Python 3.11、3.12 均有完整结果，核心测试不依赖个人 OLS 路径。
2. 已有场景通过 AgentService 换臂、换夹爪、换相机三条路径均可完成；外部服务 mock 测试覆盖异常。
3. 只换相机／夹爪不重置机械臂；只换臂能正确保持夹爪资产并重挂。
4. 无夹爪新增、底座往返、首轮切换、ID 历史空洞／重启场景均通过。
5. 普通对象、桌面、灯光和非目标相机不可被 platform_rebind 夹带修改。
6. 持物、未知运行状态、外部执行中、owner／lease 不匹配均在副作用前阻断。
7. ACK 丢失、TypeError、回执不匹配、checkpoint／unlock 失败不重复提交，未知结果按原事务恢复。
8. original 冻结不变；manifest 与最终 Scene 一致；Profile 与装配一致；不能自动开启 Control。
9. 多子句正确区域保持，live v3.1 与 replay 兼容路径边界明确。
10. 干净 CI、正式 wheel、源码目录外 smoke 通过；真实联调结果单列。真实服务不可用时可交付代码修复，但必须把 L3 标为未验收。

**不允许的“修复”：**删除安全校验、捕获所有异常返回成功、重用旧命令、把未注册平台一律设为 supported、退役 ID 回收、隐式重载旧场景、修改测试预期去迎合错误输出、只检查截图、核心测试全部 skip、自动修改 OLS 资产包、自动推送。

---

## 18. 事实来源定位

本方案事实部分基于 `evidence/implementation_review.md` 的 R1—R10 和“本轮不应误报的点”，源码路径与固定提交在该报告的 S01—S12 索引中。

- RB01—RB10 的原始观察值：`evidence/isolated_results.json`。
- 远端固定提交 CI 记录：`evidence/ci_evidence_summary.txt`。
- 探针环境与来源摘要：`evidence/sources_manifest.json`。

这些证据保持原样用于定位，不是本方案执行后的结果。所有新的修复测试须在实际工作树上重新运行，并记录对应 SHA。
