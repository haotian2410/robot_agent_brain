# 0415164 整改：回归测试与验收规范

本文件包含 **75 个逻辑场景规范**，全部状态为 `not_run`。这是实施要求，不是可直接输入现有 batch v2 编译器的工作簿，也不是已执行结果。参数化后 pytest 的实际用例数可以不同。

## 1. 执行规则

每个测试必须调用被测仓库的真实类／函数。可以 mock 外部网络、时钟、故障和持久化边界，不允许把被测 Session、Scene 协议和 adapter 都替换为审查探针中的简化对象。

先在修改前验证缺陷用例确实失败，再把断言改为正确的期望并实施修复。审查探针的 `reproduced=true` 只表示旧缺陷存在，不能作为修复通过证据。

所有测试记录当前 SHA、Python 版本、pytest node ID／实际命令、结果和证据路径。无服务标为 `not_run` 或 `blocked_environment`，不填 `passed`。

## 2. 共用 fixture

建议创建合法最小 OLS metadata fixture：臂 A 带底座、臂 B 不带底座，连接点不同；两种夹爪；世界相机和腕部相机；主桌面和普通物体；非零 now 关节与不同 initial；正确与无关 Profile。所有目录由 tmp_path 生成或提交最小 fixture，不需要生产 OBJ、纹理或个人路径。

用真实 `SceneConfig`／adapter 加载并验证这些数据。额外未知字段仅在现有 lossless 协议确实允许的组件处设置；不能用无效 fixture 测出与目标 bug 无关的失败。

## 3. 所有事务测试的共同断言

- 明确是提交前拒绝、确认拒绝、确认提交还是未知；不能都叫失败。
- 保留 before 和 candidate 的 identity/version/sub_version/digest；检查完整非目标对象。
- 记录 Brain 发起的修改 RPC 数；readback/adopt/query 不是新写。ID 预留另行记录。
- 预提交失败业务场景不变；未知结果不得声称外部不变，必须阻断后续写入和派发。
- 事务恢复不自动重载旧场景；original 保持既有冻结规则。
- 每一层均保持 `executed=false`，不调用 Control、IK 或真实机械臂。

## 4. 用例索引

| ID | 任务 | 层级 | 优先级 | 场景 |
|---|---|---|---|---|
| AUTH01 | R1 | service_mock | P0 | 已有场景由当前 Agent owner 换装 |
| AUTH02 | R1 | service_mock | P0 | 其他任务不能借用 agent_owned 权限 |
| AUTH03 | R1 | service_mock | P0 | 过期租约或 generation 不匹配 |
| AUTH04 | R1 | service_mock | P0 | 跨 session/browser 的上下文不可授权 |
| AUTH05 | R1 | service_mock | P0 | 浏览器已经提交的合法平台快照只采用一次 |
| AUTH06 | R1 | service_mock | P0 | 活跃任务期间浏览器手工换装不允许 |
| PART01 | R2 | unit | P0 | 只换相机保留完整机械臂状态 |
| PART02 | R2 | unit | P0 | 只换夹爪不重置机械臂 |
| PART03 | R2 | service_mock | P0 | 同资产请求为 no-op |
| PART04 | R2 | unit | P0 | 组合换装保持所有无关数据 |
| PART05 | R2 | unit | P1 | 相机资源切换不猜光学参数 |
| MOUNT01 | R3 | unit | P0 | 换臂但保留夹爪必须重挂 |
| MOUNT02 | R3 | unit | P0 | 换夹爪保留臂时核对 child_link |
| MOUNT03 | R3 | unit | P0 | 臂和夹爪同时更换使用新连接对 |
| MOUNT04 | R3 | unit | P0 | 连接缺失或不兼容不得补空值 |
| MOUNT05 | R3 | unit | P0 | 多个连接点不得任取第一项 |
| MOUNT06 | R3 | unit | P0 | 腕部附件重挂与世界固定相机区分 |
| ID01 | R4 | unit | P0 | 首次新增夹爪不读取旧索引中的新 ID |
| ID02 | R4 | service_mock | P0 | 底座往返切换不复用退役 ID |
| ID03 | R4 | unit | P0 | 同轮新增夹爪和底座使用不同授权 ID |
| ID04 | R4 | service_mock | P0 | 预留失败与重启保持高水位 |
| ID05 | R4 | unit | P1 | ID 上限不溢出或回绕 |
| ID06 | R4 | service_mock | P1 | 浏览器合法预留 ID 与 Agent 分配不会冲突 |
| DIFF01 | R5 | service_mock | P0 | 合法换装夹带普通对象原 ID 换资产必须拒绝 |
| DIFF02 | R5 | unit | P0 | 普通物体移动或删除不能夹带 |
| DIFF03 | R5 | unit | P0 | 桌面/灯光变更不能夹带 |
| DIFF04 | R5 | unit | P0 | 未请求的相机参数和关节限位不可修改 |
| DIFF05 | R5 | unit | P0 | 伪造 Semantic 角色或 manifest 不能扩大权限 |
| DIFF06 | R5 | unit | P0 | 合法必要底座差异和扩展字段保留 |
| TX01 | R6 | service_mock | P0 | 持物时不换装且不清空持物证据 |
| TX02 | R6 | service_mock | P0 | 显式未知运行状态/恢复状态阻断 |
| TX03 | R6 | service_mock | P0 | 执行中及暂停/关闭不可换装 |
| TX04 | R6 | service_mock | P0 | 新建纯编辑器会话不虚构运行状态 |
| TX05 | R6 | service_mock | P0 | load 内部 TypeError 不再次发起修改 |
| TX06 | R6 | service_mock | P0 | 明确写前失败不误报已提交 |
| TX07 | R6 | service_mock | P0 | ACK 丢失但同一事务可证明已提交 |
| TX08 | R6 | service_mock | P0 | 确认拒绝且现场未改 |
| TX09 | R6 | service_mock | P0 | 错误回执或现场摘要不符必须隔离 |
| TX10 | R6 | service_mock | P0 | 提交确认后 checkpoint 或解锁失败 |
| TX11 | R6 | service_mock | P0 | 进程崩溃后按旧事务恢复，不加载旧场景 |
| CAP01 | R7 | unit | P1 | 已验证内置 UR5e 兼容路径保持 |
| CAP02 | R7 | unit | P1 | 非 UR5e 有完整匹配 Profile 可识别 |
| CAP03 | R7 | unit | P0 | 无关 Profile 存在不能授权当前装配 |
| CAP04 | R7 | service_mock | P1 | 无 Profile 的展示切换成功但机器人任务受限 |
| CAP05 | R7 | unit | P0 | 多匹配、部署不匹配及重启不可盲信 supported |
| INIT01 | R8 | service_mock | P0 | 空会话首句换到无底座平台 |
| INIT02 | R8 | service_mock | P0 | 首轮无效装配不先加载默认平台 |
| INIT03 | R8 | service_mock | P1 | 已有 original 不被换装覆盖 |
| INIT04 | R8 | service_mock | P0 | 首轮 ACK 丢失不重新 bootstrap |
| INIT05 | R8 | service_mock | P1 | 恢复 original 后平台绑定按实际 Scene 重算 |
| SEM01 | R9 | unit | P0 | 正确的左上/右下多操作不被广播 |
| SEM02 | R9 | unit | P1 | 多子句反序和连接词变换 |
| SEM03 | R9 | unit | P1 | 同类物体在不同角落 |
| SEM04 | R9 | unit | P1 | 中心与角落混合 |
| SEM05 | R9 | unit | P0 | 对象相对关系与桌面区域混合 |
| SEM06 | R9 | unit | P1 | 模型漏字段与用户缺参照区分 |
| SEM07 | R9 | unit | P1 | 规范化幂等且只填明确默认 |
| ENV01 | R10 | environment | release | 干净 Python 3.11/3.12 核心测试 |
| ENV02 | R10 | environment | release | 外部集成 fixture 显式配置 |
| ENV03 | R10 | environment | release | 正式 wheel 与源码目录外 smoke |
| ENV04 | R10 | environment | release | 验收报告不伪造状态 |
| WIRE01 | R11 | service_mock | P0 | live 缺失版本不可进入兼容早退 |
| WIRE02 | R11 | service_mock | P1 | live 显式旧版本/未知版本不可自行降级 |
| WIRE03 | R11 | service_mock | P0 | 精确选型检查与请求快照一致 |
| WIRE04 | R11 | unit | P1 | 显式 replay 旧数据仍兼容 |
| EDGE01 | R12 | unit | P1 | 双臂换装明确拒绝而旧双臂能力保留 |
| EDGE02 | R12 | unit | P1 | 多个相机不隐式全量替换 |
| EDGE03 | R12 | service_mock | P1 | 目录热更新与在途事务快照不混用 |
| EDGE04 | R12 | service_mock | P0 | Gateway 不支持平台 rebind 时写前失败 |
| LIVE01 | R1 | live_integration | release | 真实已有场景换臂并保留夹爪 |
| LIVE02 | R2 | live_integration | release | 真实只换相机保持非零关节状态 |
| LIVE03 | R3 | live_integration | release | 真实只换夹爪与首次新增夹爪 |
| LIVE04 | R4 | live_integration | release | 真实平台往返切换 |
| LIVE05 | R8 | live_integration | release | 真实空会话首句切换再编辑 |
| LIVE06 | R6 | live_integration | release | 隔离测试环境的未知提交恢复 |

## 5. 逐项要求

### AUTH01 · 已有场景由当前 Agent owner 换装

**任务／层级／优先级：** R1 / service_mock / P0。**状态：not_run。**

**前置：** 合法已初始化单臂 Scene；setup 进入正常 worker 后为 agent_owned；假 Qwen 输出合法 robot_asset_switch；Mock Gateway 发放与 task/session/browser 匹配的租约。

**动作：** 从真实 startTask/AgentService.execute 路径发起换臂，不直接调用 adapter 跳过 worker。

**正确预期：**
1. 不得报 platform_rebind_task_busy。
2. 当前任务可以在自己的租约内提交，phase 不临时改为 setup。
3. 成功后版本和绑定一致，最终释放租约。
4. executed=false。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 入口请求；phase/owner 轨迹；修改请求计数；回执；before/after Scene。

### AUTH02 · 其他任务不能借用 agent_owned 权限

**任务／层级／优先级：** R1 / service_mock / P0。**状态：not_run。**

**前置：** 任务 A 持有会话租约；任务 B 使用同一 session 请求换装。

**动作：** 调用统一换装入口。

**正确预期：**
1. 拒绝 owner 不匹配。
2. 不发出修改请求。
3. A 的租约、场景、绑定不受影响。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** owner 证据；请求计数；场景摘要。

### AUTH03 · 过期租约或 generation 不匹配

**任务／层级／优先级：** R1 / service_mock / P0。**状态：not_run。**

**前置：** 同一 task 名字但 lease 已过期或被更新。

**动作：** 请求修改或在预检后、提交前改变租约 generation；分别运行。

**正确预期：**
1. 提交前复核失效租约并拒绝。
2. 不通过修改 phase 或重获无关租约继续当前事务。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 租约版本；拒绝原因；请求计数。

### AUTH04 · 跨 session/browser 的上下文不可授权

**任务／层级／优先级：** R1 / service_mock / P0。**状态：not_run。**

**前置：** 合法 task 和 token 属于另一 browser 或 session；分别构造。

**动作：** 对目标会话发起切换。

**正确预期：**
1. 拒绝身份不一致。
2. 公开 payload 自报 authorized/origin 不能赋予权限。
3. 目标和来源会话均不修改。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 身份组合；两会话摘要；请求计数。

### AUTH05 · 浏览器已经提交的合法平台快照只采用一次

**任务／层级／优先级：** R1 / service_mock / P0。**状态：not_run。**

**前置：** before 为 setup 且无活跃任务；浏览器合法候选已存在于 Gateway live state，有当前协议能提供的归属和版本证据。

**动作：** 通过 change_kind=platform_rebind 同步该快照。

**正确预期：**
1. 不会被普通平台不可变预检无条件拦截。
2. 经同一限域 validator 校验后 adopt。
3. Brain 不再次发送 load_scene/commitWorld。
4. 本地状态与已观察外部提交一致，记录 adopted 来源。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 可信外部证据；live digest；本地采用结果；修改请求计数。

### AUTH06 · 活跃任务期间浏览器手工换装不允许

**任务／层级／优先级：** R1 / service_mock / P0。**状态：not_run。**

**前置：** 已有 Agent 或外部执行占用会话，浏览器尝试上报平台变化。

**动作：** 提交手工快照或请求。

**正确预期：**
1. 拒绝手工变更授权。
2. 若 live 已被修改，标记不一致并按恢复流程处理，不谎称现场未变。
3. 不能将手工来源伪装成当前 Agent owner。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** phase；来源；live/before digest；恢复状态。

### PART01 · 只换相机保留完整机械臂状态

**任务／层级／优先级：** R2 / unit / P0。**状态：not_run。**

**前置：** 真实 SceneConfig；arm now=[0.7,-0.4]，initial 不同；OLS 默认 now=[0,0]；含合法扩展组件。

**动作：** adapter 构造 camera-only 候选。

**正确预期：**
1. 机械臂整个对象/所有组件与 before 相同，包括 RobotDriver。
2. 夹爪、底座、桌面、普通物体和非目标相机不变。
3. 仅目标相机批准字段改变。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 逐字段 diff；原始 now/initial；候选 Scene。

### PART02 · 只换夹爪不重置机械臂

**任务／层级／优先级：** R2 / unit / P0。**状态：not_run。**

**前置：** 非零机械臂当前状态和合法旧夹爪。

**动作：** 构造 gripper-only 候选并走 Session 确认路径。

**正确预期：**
1. 机械臂 RobotDriver 与 Transform 完整保持。
2. 新夹爪不继承旧夹爪的已知开合状态。
3. 受影响末端绑定失效，不把无关机械臂状态清空。

**Brain 发起的场景修改请求数：** adapter=0；事务成功=1。

**必须保存的证据：** 组件 diff；运行状态 before/after。

### PART03 · 同资产请求为 no-op

**任务／层级／优先级：** R2 / service_mock / P0。**状态：not_run。**

**前置：** 当前装配合法；请求名或别名最终解析为同一组精确 key；已有 Profile、状态和导出计划。

**动作：** 经合法所有权入口重复请求当前装配。

**正确预期：**
1. 不提交修改；scene_id/version/sub_version/digest 均不变。
2. 不重定位机械臂、不重置关节、不清空有效 Profile/状态/命令。
3. 返回已是当前配置，不声称执行。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** before/after 身份与状态；请求计数；no-op 结果。

### PART04 · 组合换装保持所有无关数据

**任务／层级／优先级：** R2 / unit / P0。**状态：not_run。**

**前置：** 普通对象带颜色、姿态、层级和未知扩展组件；平台包含非目标相机、桌面和灯光。

**动作：** 同时更换臂、夹爪和一个相机。

**正确预期：**
1. 所有非目标、非必要依赖对象 lossless 保持。
2. 只有请求的变更和经证明必要的依赖变更出现在 diff 中。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 完整对象 diff；允许变更集合。

### PART05 · 相机资源切换不猜光学参数

**任务／层级／优先级：** R2 / unit / P1。**状态：not_run。**

**前置：** 目标相机资产无权威新内参；Scene 中已有明确 Camera 参数。

**动作：** 只请求相机资源切换。

**正确预期：**
1. 按已确认的相机契约保留 Camera 参数或明确拒绝缺失配置，不伪造参数。
2. 参数策略被写入诊断和测试说明。
3. 机械臂仍完整保持。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 相机参数来源；候选 Camera diff。

### MOUNT01 · 换臂但保留夹爪必须重挂

**任务／层级／优先级：** R3 / unit / P0。**状态：not_run。**

**前置：** 合成 arm A 的连接点 old_tool；arm B 为 new_tool；相同夹爪可兼容二者。

**动作：** 仅传 robot_asset=B。

**正确预期：**
1. 夹爪资产 key、实例 ID 保持。
2. parent_joint/link 更新至 B 的有效连接。
3. Transform.parent 与 RobotAttachment 父引用一致。
4. 不残留 old_tool。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 挂接前后字段；兼容依据。

### MOUNT02 · 换夹爪保留臂时核对 child_link

**任务／层级／优先级：** R3 / unit / P0。**状态：not_run。**

**前置：** 臂不变；夹爪 A/B 的 child_link 不同且有合法映射。

**动作：** 仅更换夹爪。

**正确预期：**
1. child_link 使用 B 的合法值；parent_joint/link 仍属于当前臂。
2. 不复制 A 的连接假设。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 挂接映射；组件 diff。

### MOUNT03 · 臂和夹爪同时更换使用新连接对

**任务／层级／优先级：** R3 / unit / P0。**状态：not_run。**

**前置：** 目标臂与目标夹爪有唯一可验证连接对。

**动作：** 同时换两者。

**正确预期：**
1. 连接对来自两个目标资产契约。
2. 不先按旧夹爪校验后忘记覆盖；不复用旧臂字段。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 选择的连接对；来源 revision。

### MOUNT04 · 连接缺失或不兼容不得补空值

**任务／层级／优先级：** R3 / unit / P0。**状态：not_run。**

**前置：** 分别缺 parent_joint、parent_link、child_link、必要变换或兼容约束。

**动作：** 构造切换计划。

**正确预期：**
1. 明确失败或有依据的澄清。
2. 不填空字符串/零位姿制造成功。
3. before 不变，没有外部修改。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 缺失字段路径；错误分类；before 摘要。

### MOUNT05 · 多个连接点不得任取第一项

**任务／层级／优先级：** R3 / unit / P0。**状态：not_run。**

**前置：** 两个可连接点，顺序变化时仍无唯一语义选择。

**动作：** 请求不提供可消歧信息的换装。

**正确预期：**
1. 明确连接歧义，或使用有明确部署依据的映射。
2. 列表排列不改变选择结论；不能取 [0]。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 候选连接点；消歧结果。

### MOUNT06 · 腕部附件重挂与世界固定相机区分

**任务／层级／优先级：** R3 / unit / P0。**状态：not_run。**

**前置：** Scene 中有明确 RobotAttachment 腕部相机和独立世界固定相机。

**动作：** 更换机械臂。

**正确预期：**
1. 受影响腕部附件重新校验；世界固定相机不动。
2. 所有引用有效、无环；不使用父位姿冒充附件世界位姿。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 装配图；相机 diff；引用检查。

### ID01 · 首次新增夹爪不读取旧索引中的新 ID

**任务／层级／优先级：** R4 / unit / P0。**状态：not_run。**

**前置：** 无夹爪；合法机械臂；已预留新 ID=20。

**动作：** 添加夹爪并继续处理底座分支。

**正确预期：**
1. 不出现 scene_object_missing:20。
2. 新 ID 仅使用一次，candidate index 与对象集合一致。
3. before 无新增对象。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** candidate IDs；索引查询；before/after 分离。

### ID02 · 底座往返切换不复用退役 ID

**任务／层级／优先级：** R4 / service_mock / P0。**状态：not_run。**

**前置：** 底座 ID=6 已用过；切到无底座平台后删除 6；会话高水位为20。

**动作：** 再切回需要底座的平台。

**正确预期：**
1. 新底座 ID>=20 且不等于6。
2. Session 不报 scene_object_id_reused。
3. manifest 反映新底座；每个有效切换只提交一次。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** seen/retired/highwater；提交 diff；manifest。

### ID03 · 同轮新增夹爪和底座使用不同授权 ID

**任务／层级／优先级：** R4 / unit / P0。**状态：not_run。**

**前置：** 当前无夹爪和底座；目标装配需要两者；提供连续或离散合法预留 ID。

**动作：** 一次构造目标装配。

**正确预期：**
1. 两部件分配不同、未使用的 ID。
2. 引用均指向实际候选对象。
3. 任何分支不自行 max(current)+1。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 分配记录；对象和引用集合。

### ID04 · 预留失败与重启保持高水位

**任务／层级／优先级：** R4 / service_mock / P0。**状态：not_run。**

**前置：** 先为失败事务预留 ID，然后恢复服务；场景仍是 before。

**动作：** 新事务重新请求需要新增部件的换装。

**正确预期：**
1. 已预留/已见/已退役 ID 按权威契约不重复分配。
2. 持久化后 next 不下降；允许 ID 空洞。
3. 失败场景和版本不变。

**Brain 发起的场景修改请求数：** 失败=0；新成功=1。

**必须保存的证据：** allocator checkpoint；重启前后状态。

### ID05 · ID 上限不溢出或回绕

**任务／层级／优先级：** R4 / unit / P1。**状态：not_run。**

**前置：** 分配高水位接近 scene_id_bits 定义的上限。

**动作：** 分别请求可表示和无法表示的新增部件数量。

**正确预期：**
1. 按现有计数器契约分配最后合法范围或明确耗尽。
2. 绝不生成越界/负/回绕 ID，也不破坏现有 Scene。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 边界输入；分配结果/耗尽错误。

### ID06 · 浏览器合法预留 ID 与 Agent 分配不会冲突

**任务／层级／优先级：** R4 / service_mock / P1。**状态：not_run。**

**前置：** 浏览器获得合法分配记录导致 next 前进，随后提交候选；另一个分配请求排队。

**动作：** 同步候选并按既有锁策略处理后续分配。

**正确预期：**
1. 不因 new_id<next 而错误拒绝本事务已预留 ID。
2. 不同事务不重用相同 ID。
3. 任意客户端自报的未授权 ID 不被接受。

**Brain 发起的场景修改请求数：** 采用=0。

**必须保存的证据：** 分配授权；next 变化；并发顺序。

### DIFF01 · 合法换装夹带普通对象原 ID 换资产必须拒绝

**任务／层级／优先级：** R5 / service_mock / P0。**状态：not_run。**

**前置：** 苹果是普通任务对象，不是平台部件；候选同时合法换臂并把该苹果原 ID 换成香蕉。

**动作：** 分别从 Agent 候选和 browser 同步入口验证。

**正确预期：**
1. 检测到未批准的 MetadataRef 替换。
2. Agent 在外写前拒绝；browser 已改则拒绝采用并报告不同步。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 允许/实际 diff；拒绝字段路径。

### DIFF02 · 普通物体移动或删除不能夹带

**任务／层级／优先级：** R5 / unit / P0。**状态：not_run。**

**前置：** 合法 rebind 候选中额外移动或删除一个普通对象；分别运行。

**动作：** 调用共享 validator。

**正确预期：**
1. 不因 platform_rebind 而跳过普通对象保护。
2. 返回精确对象和差异字段；不得归一化掉非法变化。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 对象 diff；错误详情。

### DIFF03 · 桌面/灯光变更不能夹带

**任务／层级／优先级：** R5 / unit / P0。**状态：not_run。**

**前置：** 候选除请求换装外还移动/缩放桌面或修改灯光；分别运行。

**动作：** 验证 rebind。

**正确预期：**
1. 三种变更分别被拒绝。
2. manifest 声明不能给予桌面或灯光任意变更权限。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** non-target diff；验证证据。

### DIFF04 · 未请求的相机参数和关节限位不可修改

**任务／层级／优先级：** R5 / unit / P0。**状态：not_run。**

**前置：** camera-only 改到了另一相机或 arm joint_limits；gripper-only 改到了 arm driver。

**动作：** 验证各候选。

**正确预期：**
1. 非目标或越角色字段修改被拒绝。
2. 即使 key 存在、引用合法也不能通过。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 组件/字段级 diff。

### DIFF05 · 伪造 Semantic 角色或 manifest 不能扩大权限

**任务／层级／优先级：** R5 / unit / P0。**状态：not_run。**

**前置：** 把普通对象在 candidate 标为 robot_support，并放入 platform_object_ids。

**动作：** 尝试删除/替换这个对象。

**正确预期：**
1. 依据 before 可信角色判定，不依据 candidate 自报角色。
2. 拒绝未经授权的角色提升与对象改变。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** before 角色来源；candidate 伪造字段。

### DIFF06 · 合法必要底座差异和扩展字段保留

**任务／层级／优先级：** R5 / unit / P0。**状态：not_run。**

**前置：** 目标臂确实需要添加/替换/删除对应底座；before 含合法未知扩展字段。

**动作：** 验证 adapter 的合法候选。

**正确预期：**
1. 仅必要底座变化通过。
2. 未涉及扩展字段按 lossless 契约保留；不把合法 diff 误拒绝。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 角色来源；完整 diff；序列化摘要。

### TX01 · 持物时不换装且不清空持物证据

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** holding_object 非空或一条 arm 持物。

**动作：** 分别经 CLI/internal task 和 browser 入口换装。

**正确预期：**
1. 两条路径均拒绝。
2. 不调用平台修改。
3. holding、arm_states、scene、Profile 保持，不以清空状态通过检查。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 两入口结果；完整状态快照。

### TX02 · 显式未知运行状态/恢复状态阻断

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 分别 state_known=false、sync unknown、pending recovery、quarantine。

**动作：** 请求切换。

**正确预期：**
1. 各状态均拒绝有副作用的切换。
2. 不通过 editor-only 标记重置已有风险证据。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 状态分支；请求计数。

### TX03 · 执行中及暂停/关闭不可换装

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 分别 pending execution、已派发未确认、session paused、session closed。

**动作：** 请求切换。

**正确预期：**
1. 按既有 Session 语义拒绝。
2. 不退役命令、不改装配、不自动 resume。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 任务/会话状态；错误码。

### TX04 · 新建纯编辑器会话不虚构运行状态

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 明确 editor-only、无 Control、无执行历史/持物/未知记录；尚无真实机器人状态。

**动作：** 进行合法展示换装。

**正确预期：**
1. 可以按明确编辑模式完成展示配置。
2. 不把 OLS 默认关节值设为真实已知状态。
3. executed=false，Control 未启用。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 运行模式依据；最终 readiness/capability。

### TX05 · load 内部 TypeError 不再次发起修改

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 真实 Port 实现支持 change_kind；MockTransport 或平台 adapter 在已开始外写后抛 TypeError。

**动作：** 执行一次合法 rebind。

**正确预期：**
1. 外部修改调用最多一次。
2. 绝不以缺省 scene_edit 再调用 loader。
3. 按证据进入查询/unknown，不能无依据 synchronized。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 调用序列；transaction_id；最终 sync。

### TX06 · 明确写前失败不误报已提交

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 在能力预检、连接校验或发送前的确定性错误。

**动作：** 执行换装。

**正确预期：**
1. 零外写。
2. 报告预提交拒绝；before 场景/绑定保持。
3. 仅有证明无写入时才判 unchanged；不靠异常类型猜测。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 失败阶段；write_attempted；before 摘要。

### TX07 · ACK 丢失但同一事务可证明已提交

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 首次 commit 超时；queryWorldCommit 返回匹配 transaction 的 committed 回执；live digest 等于 candidate。

**动作：** 执行现有事务查询恢复。

**正确预期：**
1. 只发送一次 commit。
2. 根据同一事务证据完成本地 checkpoint。
3. 不另建事务重写同一个场景。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 首次请求；查询响应；live digest；checkpoint。

### TX08 · 确认拒绝且现场未改

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** Gateway 返回归属正确的 rejected，live digest 仍是 before。

**动作：** 处理拒绝。

**正确预期：**
1. 保留 before 场景、绑定、manifest 和 revision。
2. 记录拒绝事实；按既有授权正常结束/解锁。
3. 不重新提交。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 拒绝回执；live digest；状态保持。

### TX09 · 错误回执或现场摘要不符必须隔离

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 分别事务/browser/session/版本不匹配、回执成功但 live digest 不符、查不到事务。

**动作：** 处理外部响应。

**正确预期：**
1. 每个反例均不能判成功。
2. unknown/quarantine；阻断后续修改与旧命令派发。
3. 保存 before 和 candidate，不伪造回滚。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 错误回执；live 读回；后续任务拒绝。

### TX10 · 提交确认后 checkpoint 或解锁失败

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** 外部 committed 已有证据；分别模拟本地保存失败、release lease 不确定。

**动作：** 完成事务后半段。

**正确预期：**
1. 报告已确认外部事实和后续恢复需求。
2. 不声称未提交，不在未确认状态下允许下一任务。
3. 保持可恢复日志，不再发写。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 提交回执；保存/解锁异常；恢复记录。

### TX11 · 进程崩溃后按旧事务恢复，不加载旧场景

**任务／层级／优先级：** R6 / service_mock / P0。**状态：not_run。**

**前置：** prepared/unknown 事务持久化后进程重启；外部可能已经应用 candidate。

**动作：** 恢复 Session 并进行证据核验。

**正确预期：**
1. 恢复本身不 load_scene、不发送新 commit。
2. 同一 transaction 核验后才能提交本地或确认未变。
3. 证据不足继续隔离，original 不被覆盖。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 重启请求计数；恢复 journal；original digest。

### CAP01 · 已验证内置 UR5e 兼容路径保持

**任务／层级／优先级：** R7 / unit / P1。**状态：not_run。**

**前置：** 符合历史已验证部署的 UR5e/driver/末端配置，使用明确 legacy descriptor。

**动作：** 导入、恢复和切换后分别判定能力。

**正确预期：**
1. 三入口判定一致。
2. 旧单臂规划能力不因本次收紧全部失效。
3. 配置字符串本身不是唯一支持证据。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** Profile/descriptor 匹配依据；三个入口结果。

### CAP02 · 非 UR5e 有完整匹配 Profile 可识别

**任务／层级／优先级：** R7 / unit / P1。**状态：not_run。**

**前置：** 合成平台有完整兼容 Profile，而非只注册同名字符串。

**动作：** 调用统一能力解析。

**正确预期：**
1. 不因非 ur5e_arm 被无条件判 unsupported。
2. matched profile、deployment 校验和 state readiness 分别记录。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 注册 Profile；匹配证据。

### CAP03 · 无关 Profile 存在不能授权当前装配

**任务／层级／优先级：** R7 / unit / P0。**状态：not_run。**

**前置：** 当前平台没有兼容配置，registry 仅有另一个平台 Profile。

**动作：** 请求能力判断和 robot_task。

**正确预期：**
1. 不会因 bool(profiles) 为真而 supported。
2. robot_task 明确 capability_unsupported；不输出错误规划命令。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** registry/装配差异；拒绝和产物检查。

### CAP04 · 无 Profile 的展示切换成功但机器人任务受限

**任务／层级／优先级：** R7 / service_mock / P1。**状态：not_run。**

**前置：** 资产、挂接与场景有效，但没有该装配的规划 Profile。

**动作：** 先展示切换，随后查询/新增，再明确请求机器人动作。

**正确预期：**
1. 展示切换成功并保留 executed=false。
2. 查询/合法场景编辑仍可工作。
3. 机器人任务受限，不把前面的展示提交误报失败。

**Brain 发起的场景修改请求数：** 切换=1；查询/动作无额外换装写。

**必须保存的证据：** 逐轮结果；能力理由；命令产物。

### CAP05 · 多匹配、部署不匹配及重启不可盲信 supported

**任务／层级／优先级：** R7 / unit / P0。**状态：not_run。**

**前置：** 分别两个同等匹配 Profile、joint/limit/gripper/TCP 不匹配、持久化 supported 与实际 Scene 冲突。

**动作：** 进行绑定或重启恢复。

**正确预期：**
1. 歧义需要显式选择，部署不匹配拒绝规划。
2. 不把元数据初始关节当实时状态。
3. 不从旧 supported 字符串直接恢复执行权限。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 匹配失败详情；恢复后的实际绑定。

### INIT01 · 空会话首句换到无底座平台

**任务／层级／优先级：** R8 / service_mock / P0。**状态：not_run。**

**前置：** 未初始化 bootstrap placeholder；默认模板有底座；目标不需要底座。

**动作：** 首轮请求换装，随后查询和增加普通物体。

**正确预期：**
1. 仅提交最终创建场景一次，version=1/sub=0。
2. manifest 不含旧底座且只含最终平台对象。
3. 后续两轮不会因 stale manifest 失败。

**Brain 发起的场景修改请求数：** 首轮=1。

**必须保存的证据：** 全部修改请求；最终 manifest；后续结果。

### INIT02 · 首轮无效装配不先加载默认平台

**任务／层级／优先级：** R8 / service_mock / P0。**状态：not_run。**

**前置：** 空会话；分别未知目标资产、不兼容挂接或关键元数据缺失。

**动作：** 请求首轮换装。

**正确预期：**
1. 不调用 initialize_scene 提交中间模板。
2. Scene/original 未被错误创建。
3. 结果明确拒绝，不留下半初始化状态。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 请求计数；Scene/original 状态。

### INIT03 · 已有 original 不被换装覆盖

**任务／层级／优先级：** R8 / service_mock / P1。**状态：not_run。**

**前置：** 已上传并冻结 original；current 已发生编辑。

**动作：** 完成平台切换。

**正确预期：**
1. original 内容和摘要保持。
2. current 更新到目标平台。
3. manifest 从最终 current 得到，不从旧模板覆盖。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** original 前后 digest；current diff；manifest。

### INIT04 · 首轮 ACK 丢失不重新 bootstrap

**任务／层级／优先级：** R8 / service_mock / P0。**状态：not_run。**

**前置：** 首轮最终 candidate 提交后响应丢失，进程或任务需恢复。

**动作：** 按 transaction 重新查询证据。

**正确预期：**
1. 不发送第二次创建或换装写。
2. 确认提交后只冻结正确最终 generated original 一次。
3. 未确认时保留 unknown。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** transaction 查询；写次数；original 创建记录。

### INIT05 · 恢复 original 后平台绑定按实际 Scene 重算

**任务／层级／优先级：** R8 / service_mock / P1。**状态：not_run。**

**前置：** original 为平台 A，current 切成 B；后续合法恢复/派生 original。

**动作：** 走既有恢复路径。

**正确预期：**
1. 新的装配身份、manifest、Profile 与实际恢复场景一致。
2. 不沿用 B 的 capability 或旧实例映射。
3. 历史 original 本身保持冻结。

**Brain 发起的场景修改请求数：** 按既有恢复事务，最多一次。

**必须保存的证据：** 恢复 Scene；新映射；original digest。

### SEM01 · 正确的左上/右下多操作不被广播

**任务／层级／优先级：** R9 / unit / P0。**状态：not_run。**

**前置：** 输入“在桌面左上角增加苹果，在桌面右下角增加香蕉”；模型已分别给 left_front/right_back。

**动作：** 执行真实 normalize 和 parse。

**正确预期：**
1. 两个区域保持各自值。
2. 数量、目标、顺序和 asset_choices 不变。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** raw/normalized/canonical JSON。

### SEM02 · 多子句反序和连接词变换

**任务／层级／优先级：** R9 / unit / P1。**状态：not_run。**

**前置：** 右下在前、左上在后；使用逗号、然后、再等表达，模型结构均正确。

**动作：** 逐例规范化。

**正确预期：**
1. 区域绑定不取决于全句关键词查找顺序。
2. 每个对象仍关联正确区域。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 参数化表达与输出。

### SEM03 · 同类物体在不同角落

**任务／层级／优先级：** R9 / unit / P1。**状态：not_run。**

**前置：** 两个明确声明的苹果实体，分别对应不同位置。

**动作：** 规范化新增计划。

**正确预期：**
1. 不按相同 semantic_name 合并实例或覆盖区域。
2. 操作与实体 ID 对应保持。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 两实体选择器；区域/数量断言。

### SEM04 · 中心与角落混合

**任务／层级／优先级：** R9 / unit / P1。**状态：not_run。**

**前置：** 模型一条 center hint、一条 right_back region；输入包含两种位置。

**动作：** 规范化与解析。

**正确预期：**
1. center 不覆盖角落，角落不覆盖 center。
2. relation/reference 合法配对。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 位置字段前后比较。

### SEM05 · 对象相对关系与桌面区域混合

**任务／层级／优先级：** R9 / unit / P0。**状态：not_run。**

**前置：** 一条在桌面左上新增；另一条在苹果右边或篮子旁边新增。

**动作：** 规范化。

**正确预期：**
1. 普通对象 right_of/near reference 保持。
2. 不变成 on apple/on basket，不无条件绑定 table。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** relation/reference diff。

### SEM06 · 模型漏字段与用户缺参照区分

**任务／层级／优先级：** R9 / unit / P1。**状态：not_run。**

**前置：** A：用户明确多个位置/参照，模型遗漏；B：用户只说最远，确实缺参照。

**动作：** 分别解析。

**正确预期：**
1. A 不全句猜测填充，不伪装成用户原句未说明；可走有限模型修复或明确模型协议错误。
2. B 返回明确澄清，不伪造距离参照。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 错误阶段；澄清理由；无场景提交。

### SEM07 · 规范化幂等且只填明确默认

**任务／层级／优先级：** R9 / unit / P1。**状态：not_run。**

**前置：** 合法多操作、裸 add、普通物体关系和已归一化输出。

**动作：** 连续调用规范化两次。

**正确预期：**
1. 第二次结果等于第一次。
2. 裸 add 仅按桌面契约填支撑，不生成新桌子，不变数量/资产/顺序。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 一次/二次 canonical 比较。

### ENV01 · 干净 Python 3.11/3.12 核心测试

**任务／层级／优先级：** R10 / environment / release。**状态：not_run。**

**前置：** 无个人 OLS 路径、无未跟踪 var 缓存的干净 checkout；安装 dev/web/batch。

**动作：** 在两种支持版本分别运行核心实际仓库测试。

**正确预期：**
1. 均提供完整通过/失败/跳过结果，不用 cancelled 代替。
2. 核心装配/契约测试不因 OLS 未安装被跳过。

**Brain 发起的场景修改请求数：** 不涉及生产修改。

**必须保存的证据：** 环境版本；完整 pytest 输出；skip 原因。

### ENV02 · 外部集成 fixture 显式配置

**任务／层级／优先级：** R10 / environment / release。**状态：not_run。**

**前置：** 基础 metadata 用 tmp_path 或提交 fixture；真实 OLS 测试单独标记。

**动作：** 分别在无外部资源和显式配置资源的测试作业运行。

**正确预期：**
1. 只有真实集成测试能 blocked/not_run。
2. 不读取硬编码 /home/cscvlab 路径。
3. 结果不与核心通过率混在一起。

**Brain 发起的场景修改请求数：** 不涉及生产修改。

**必须保存的证据：** marker/fixture 配置；实际资源版本。

### ENV03 · 正式 wheel 与源码目录外 smoke

**任务／层级／优先级：** R10 / environment / release。**状态：not_run。**

**前置：** 测试通过后的当前 SHA；独立 venv，清除 PYTHONPATH，工作目录在源码外。

**动作：** 构建 wheel，离线从 wheelhouse 安装依赖并执行现有 smoke。

**正确预期：**
1. 导入、Prompt 资源、CLI/既有 smoke 均有实际结果。
2. 不是 editable import；未运行不能记 passed。

**Brain 发起的场景修改请求数：** 不涉及生产修改。

**必须保存的证据：** wheel 文件/hash；安装日志；smoke 输出。

### ENV04 · 验收报告不伪造状态

**任务／层级／优先级：** R10 / environment / release。**状态：not_run。**

**前置：** 某些真实服务不可用，或测试失败。

**动作：** 生成最终报告和回归状态清单。

**正确预期：**
1. not_run、blocked_environment、failed、passed 分开。
2. 每个 passed 有对应 node/evidence/SHA。
3. 十个原审查 reproduced=true 不被当作修复通过。

**Brain 发起的场景修改请求数：** 不涉及生产修改。

**必须保存的证据：** 报告；案例执行记录。

### WIRE01 · live 缺失版本不可进入兼容早退

**任务／层级／优先级：** R11 / service_mock / P0。**状态：not_run。**

**前置：** 请求有效资产目录已注入；Qwen 返回缺少 protocol_version 的 add 结构。

**动作：** 调用真实 Qwen provider 的响应解析路径。

**正确预期：**
1. 明确拒绝或有限修复后重新严格校验。
2. 不跳过 asset_choices，不退回名称猜测。
3. 没有场景修改。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 实际请求/响应；错误阶段；调用次数。

### WIRE02 · live 显式旧版本/未知版本不可自行降级

**任务／层级／优先级：** R11 / service_mock / P1。**状态：not_run。**

**前置：** 同一 live 请求返回 v2、v3 或未知版本；分别运行。

**动作：** 经过完整 wire/parser/provider。

**正确预期：**
1. 与该请求预期版本不符即拒绝。
2. 模型返回值不能选择 replay 权限。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 版本测试输入；校验结果。

### WIRE03 · 精确选型检查与请求快照一致

**任务／层级／优先级：** R11 / service_mock / P0。**状态：not_run。**

**前置：** 有效快照来自 request 或 provider 当前缓存；分别构造缺key、key不在目录、name冲突、不可新增、用途多余。

**动作：** 响应解析及选择校验。

**正确预期：**
1. 所有非法情况不被有效目录来源差异绕过。
2. Prompt/body/validator 使用同一快照。
3. 不恢复 cup→mug 硬编码。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** payload/revision；各反例错误。

### WIRE04 · 显式 replay 旧数据仍兼容

**任务／层级／优先级：** R11 / unit / P1。**状态：not_run。**

**前置：** 旧录制文件只从 replay adapter 进入；没有 live 授权上下文。

**动作：** 按兼容模式转换 canonical 语义。

**正确预期：**
1. 已有合法录制样例仍可读取。
2. 同一格式不能在 live 入口以自报版本获取兼容权限。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** replay 测试；live 对照测试。

### EDGE01 · 双臂换装明确拒绝而旧双臂能力保留

**任务／层级／优先级：** R12 / unit / P1。**状态：not_run。**

**前置：** Scene 中两条臂；另有既有双臂任务/反馈回归数据。

**动作：** 请求新单臂装配 adapter 换装，并运行原双臂回归。

**正确预期：**
1. 换装前置明确说明当前范围，无部分换第一条臂。
2. 不删除既有双臂规划、反馈、快照能力。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 范围错误；旧双臂测试结果。

### EDGE02 · 多个相机不隐式全量替换

**任务／层级／优先级：** R12 / unit / P1。**状态：not_run。**

**前置：** 两个相机；分别有明确 camera_id 绑定、无唯一目标、明确批量范围。

**动作：** 请求换相机。

**正确预期：**
1. 按已确认产品契约作用于明确目标。
2. 无唯一目标时澄清；同资产名不能自动表示所有相机。
3. 批量只在协议显式支持时执行。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** 目标绑定依据；各相机 diff。

### EDGE03 · 目录热更新与在途事务快照不混用

**任务／层级／优先级：** R12 / service_mock / P1。**状态：not_run。**

**前置：** 准备切换使用 revision A；处理中发布 revision B；已有缓存 Session。

**动作：** 完成当前事务并发起下一请求。

**正确预期：**
1. 当前事务固定 A 或因不能保证一致而明确中止，不半途混用 B。
2. 下一请求和 Session adapter 使用一致的新快照策略。

**Brain 发起的场景修改请求数：** 当前至多1。

**必须保存的证据：** 两个 revision；adapter/snapshot 绑定；事务结果。

### EDGE04 · Gateway 不支持平台 rebind 时写前失败

**任务／层级／优先级：** R12 / service_mock / P0。**状态：not_run。**

**前置：** Gateway 支持旧 atomic_commit，但未声明 platform_rebind 能力。

**动作：** 请求新的装配切换。

**正确预期：**
1. 写前返回明确能力/升级错误。
2. 不降级为普通 scene_edit，不更换 transaction 重试。

**Brain 发起的场景修改请求数：** 0。

**必须保存的证据：** capabilities 响应；请求计数。

### LIVE01 · 真实已有场景换臂并保留夹爪

**任务／层级／优先级：** R1 / live_integration / release。**状态：not_run。**

**前置：** 隔离测试服务，OLS 版本明确；源/目标装配已知合法；没有 Control 接入。

**动作：** 用自然语言只指定机械臂切换，再查询当前配置。

**正确预期：**
1. 真实 Qwen 输出合规且挂接正确。
2. 只有一次换装提交；读回、manifest、能力一致。
3. 普通物体和世界固定相机不变，executed=false。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 原始Qwen；before/after；回执；读回；截图。

### LIVE02 · 真实只换相机保持非零关节状态

**任务／层级／优先级：** R2 / live_integration / release。**状态：not_run。**

**前置：** 测试场景机械臂 now 非零，明确相机目标，无真实动作执行。

**动作：** 自然语言只换相机。

**正确预期：**
1. 未变机械臂整段 RobotDriver 保持。
2. 目标范围正确，非目标相机保持。
3. 不能只以截图未移动判通过。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 组件 diff；原始Qwen；回执。

### LIVE03 · 真实只换夹爪与首次新增夹爪

**任务／层级／优先级：** R3 / live_integration / release。**状态：not_run。**

**前置：** 分别有旧夹爪和无夹爪的隔离场景，目标兼容。

**动作：** 自然语言只选择新夹爪。

**正确预期：**
1. 两条路径均有合法挂接，不出现新对象旧索引异常。
2. 机械臂状态保持，新增 ID 来源合法。

**Brain 发起的场景修改请求数：** 每次有效请求1。

**必须保存的证据：** 挂接数据；ID记录；读回。

### LIVE04 · 真实平台往返切换

**任务／层级／优先级：** R4 / live_integration / release。**状态：not_run。**

**前置：** 带底座平台与无底座平台互换；会话有删除历史/高水位。

**动作：** 连续来回切换至少两轮，每轮读回再进行下一轮。

**正确预期：**
1. 旧底座 ID 不复用。
2. 每轮 manifest、sub_version 与实际 Scene 一致。
3. 返回平台后查询/普通编辑不被历史 manifest 阻塞。

**Brain 发起的场景修改请求数：** 每次有效请求1。

**必须保存的证据：** 完整多轮日志；分配高水位；场景快照。

### LIVE05 · 真实空会话首句切换再编辑

**任务／层级／优先级：** R8 / live_integration / release。**状态：not_run。**

**前置：** 明确 bootstrap placeholder，而非已冻结上传空场景。

**动作：** 首句切换平台，随后增加物体和查询。

**正确预期：**
1. 首轮最终场景只创建一次。
2. original 与 final manifest 正确。
3. 后续步骤没有因底座残留身份失败。

**Brain 发起的场景修改请求数：** 首轮1。

**必须保存的证据：** 整个会话证据；original digest。

### LIVE06 · 隔离测试环境的未知提交恢复

**任务／层级／优先级：** R6 / live_integration / release。**状态：not_run。**

**前置：** 仅隔离测试 Gateway/浏览器，可控地模拟 ACK 丢失；用户生产场景不得用作故障注入目标。

**动作：** 完成一次切换并故障注入，再按同一事务核验。

**正确预期：**
1. 不重复写入，不误报告回滚。
2. 未知期间锁定；证据充分才恢复。
3. 环境不具备可控注入时标 not_run，Mock 层相关测试仍必须完成。

**Brain 发起的场景修改请求数：** 1。

**必须保存的证据：** 注入点；transaction；查询/恢复轨迹。

## 6. 状态维护

`03_regression_cases.json` 是同源可追踪清单。实施时可复制为执行结果文件，补充 test_node_id、executed_commit、observed_result 和证据；不要把规划文件原有 not_run 批量改成 passed。

代码修复、支持环境测试、独立 wheel、真实联调分别给结论。真实联调未运行时可以交付代码，但不能写“平台换装已完整验收”。
