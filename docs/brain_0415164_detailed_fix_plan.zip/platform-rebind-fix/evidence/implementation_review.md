# Brain 0415164：平台切换与剩余缺陷审查

审查日期：2026-11-07  
固定提交：`041516434bb34272c3d3b364cb001af2568ef7a4`  
仓库：`haotian2410/robot_agent_brain`  
上一轮审查基线：`264dc69ff158cddb95fb4b2c1864b9d39a18cea3`；两者相差54个提交，不将中间所有变更归入最后一个提交。

## 1. 结论和证据边界

本版的 OLS 装配读取、显式 platform_rebind、主版本/子版本区分以及不把“可展示资产”直接等同于“可执行能力”的设计值得保留。部分旧问题已有补强，例如资产 key 与名称/可选状态校验、非桌面参照物不再一律改成 on。

但平台切换尚不能验收为闭环。主要问题是 Web 状态机与切换入口互相阻断、配件切换覆盖机械臂状态、换臂后的挂接不重建、对象 ID 生命周期错误，以及切换例外的校验范围过宽。这些并非靠增加 Qwen Prompt 能解决。

证据分三类：

- **源码确认**：读取指定提交中的真实实现与调用链，提供函数和来源。
- **隔离复现**：抽取方法体，使用合成 Scene/目录/平台替身复现10种边界行为。没有完整克隆运行仓库。Scene替身不具备完整生产协议和几何校验；不能把某个低层接受行为解释成完整Web链路已提交成功。运行环境为Python 3.13.5，仓库声明支持3.11/3.12，因此这些是逻辑探针，不是受支持环境的产品验收。
- **远端CI证据**：GitHub Actions真实日志。没有在本环境重跑全仓pytest，没有连接用户Qwen、OLS、浏览器、Gateway，没有调用Control、IK、MuJoCo或真实机械臂。

`isolated_results.json` 的 reproduced=true 表示缺陷行为已出现，不表示对应产品功能通过。`reproduce_isolated.py` 是审查探针，不应直接放进产品测试并以它的“通过”作为修复验收；Codex须将期望改为正确行为后，在仓库实际类上补回归。

## 2. 远端验收状态

GitHub Actions运行：`42338432830`，提交与本次审查一致。Python 3.12作业：`128300521411`。

```text
21 failed, 866 passed, 10 skipped in 26.02s
```

21项失败中，8项与缺少openpyxl有关，13项依赖仓库外OLS/本地缓存/未提交场景文件。它们不能解释成21种生产业务错误，也不能因为本地环境具备这些文件就忽略干净checkout失败。

Python 3.11作业被取消。wheel和wheel smoke步骤被前面的pytest失败阻断，不能据此宣称wheel通过。新增`test_ols_robot_assembly.py`的4项测试均因本机专属OLS路径不存在而被CI跳过。

修复：CI安装`.[dev,web,batch]`；资产与装配单元测试用最小可提交metadata或tmp_path生成fixture；真实OLS集成另行标记、显式提供资源。不要把所有新测试skip来获取绿灯。详见`ci_evidence_summary.txt`与S10、S12。

## 3. 按优先级的缺陷

### R1 / P0：正常Web路径阻断平台切换

**来源：S02 `rebind_platform_assets`；S03 `execute`、`validate_scene`、start handler。**

对已有场景，Web worker执行顺序：

```text
验证当前Scene → acquire_lease → session_phase=agent_owned
→ app.handle → process_turn → rebind_platform_assets
```

但`rebind_platform_assets`遇到`session_phase == agent_owned`立即返回`platform_rebind_task_busy`。因此即便Qwen正确返回robot_asset_switch，正常Web任务入口仍会阻断（RB01复现该状态门控）。空场景首次bootstrap会调用initialize_scene重置phase，是不同路径，不能用它证明已有场景切换通过。

另一个入口问题：浏览器已经变更平台后，`StartTask.change_kind=platform_rebind`虽存在，但`start/execute`预校验调用的`validate_scene()`不接收change_kind，仍无条件要求平台部署组件不变。真正的换臂快照可能先报`web_platform_profile_unsupported`，根本到不了Session的rebind例外。此项为完整源码调用链确认，未做真实HTTP/浏览器提交。

**修复**：统一切换事务入口。手工浏览器改平台只能在setup、无活跃任务时提交；Agent发起切换可在其自身有效租约内执行，但要核对task/session/browser/lease身份。不要单纯删除agent_owned保护，更不要为切换临时释放租约。Web预校验和Session均调用同一个限域rebind校验器。

**回归**：已有场景经真实AgentService入口、假Qwen和Mock Gateway返回正确switch payload，完成一次提交；其他任务占用、过期租约、未知执行状态均拒绝。另测browser rebind的允许与禁止差异。

### R2 / P0：只换相机或夹爪，也会重写机械臂当前状态

**来源：S01 `rebind_scene`中arm_changed条件之后的无条件RobotDriver替换。RB02。**

代码只把机械臂Transform更新放在`arm_changed`条件内；随后不论是否换臂，都从OLS元数据生成机械臂RobotDriver并覆盖。`_scene_driver()`保留`now_joint_positions_rad`，所以只换相机也可能把场景当前关节值重置为OLS默认值。

合成fixture：当前关节`[0.7,-0.4]`，元数据默认`[0,0]`；只换camera后得到`[0,0]`，Transform仍相同。这解释了为什么仅断言Transform保持的现有测试发现不了问题。

**修复**：以实际资产身份变化确定changed，而不是参数非None。camera-only只能更新选定相机允许变动的组件；gripper-only不得改机械臂RobotDriver。新换机械臂的初始化值和真实测量值要分开，不能把默认值当“已知实时状态”。同资产重复请求默认no-op，除非明确重置。

**回归**：当前关节非零、初始值不同、额外driver字段存在时camera-only/gripper-only全部保持机械臂组件；无关对象完全不变。

### R3 / P0：只换臂，不换夹爪，会留下旧挂接关系

**来源：S01 `if target_gripper:`分支。RB03。**

只有用户显式给gripper_asset时才重建RobotAttachment。只给robot_asset会替换机械臂driver，却保留已有夹爪的旧parent_joint/parent_link。当新旧臂连接点不同，candidate就含有旧挂接信息。

合成fixture中旧挂接为old_tool，新臂连接点piper_tool，结果仍是old_tool。这两个字符串仅用于隔离fixture，不声称是生产OLS实际关节名。真实Gateway的joint校验可能阻断错误候选，因此不能把此复现写成“真实浏览器已挂错”。

**修复**：换臂时重新校验并绑定所有保留的末端附件；资产不换不等于连接不换。挂接点必须来自新臂与保留夹爪的装配契约；多连接点需明确兼容规则/澄清，不任取第一项。Scene Transform.parent与RobotAttachment.parent_object_id/parent_joint/parent_link/child_link一致性统一验证。

**回归**：换臂不换夹爪；换夹爪不换臂；两者同时换；连接点不同/不兼容/缺失；失败不提交。

### R4 / P1：新增配件和底座ID生命周期错误

**来源：S01 `rebind_scene`；S02 `_candidate_manager`、`rebind_platform_assets`；S07。RB04、RB05。**

**R4a：首次装夹爪会用旧SceneIndex查新对象。** 新gripper加入objects后，底座扫描仍使用`SceneIndex(scene)`，遍历新objects时查新gid导致`scene_object_missing`。RB04传入next_object_id=20后复现LookupError。

**R4b：UR5e→无底座平台→UR5e可能复用已退役底座ID。** 底座新ID取`max(objects)+1`，不使用会话历史高水位；Session调用adapter也没传next_scene_object_id。合成fixture中移除底座6，再返回需要底座的平台，又生成6，即便直接给adapter next_object_id=20仍忽略，最终被Session正确拒绝`scene_object_id_reused`。

**修复**：候选构建使用统一Allocator，从会话/平台分配器的单调高水位申请；夹爪与底座共用，禁止max(current IDs)+1。扫描只扫描旧scene，或建立一致的候选索引，不能混用。删除后不回收已用ID。

**回归**：无夹爪→新增；高水位存在历史空洞；底座往返切换；新增夹爪+底座同轮；接近ID上限；旧ID不复用。

### R5 / P0：platform_rebind例外范围过宽

**来源：S02 `accept_browser_scene`；S06引用校验。RB06。**

现有两个关键检查均以not platform_rebind为前提：已有对象MetadataRef不可原ID替换、平台对象部署组件不可变。rebind时对所有对象豁免，不只是机械臂及配件。引用校验检查对象存在，不证明修改属于允许的装配变更。

RB06在低层Session API中把普通苹果原ID变成香蕉，同时移动桌面，仍被接受；同一变更走scene_edit会被拒绝。这里使用平台替身、并未穿透真实Web/Gateway；目前过严Web预校验可能掩盖这个漏洞。修R1时必须同时修R5，否则可能把原来被入口挡住的非法改动放开。

**修复**：以before、requested change、可信目录生成允许的对象/组件字段diff白名单。普通物体、桌面、灯光、非目标相机严格不变；底座增删只能由目标臂装配需求触发；重新验证所有引用。不能相信调用方写了change_kind就跳过保护。

**回归**：在合法rebind中夹带普通对象改资产/移动/删除、桌面位移、其他相机改参、错误连接/RobotDriver修改，均拒绝且无副作用。

### R6 / P0：任务入口缺少空闲保护，TypeError兜底会重试写入

**来源：S02 `rebind_platform_assets`，对照`accept_browser_scene`的holding检查。RB07、RB08。**

任务入口只检查pending/phase/sync/recovery，没有复用browser路径的holding/已知idle检查。RB07中有持物状态仍调用load，之后holding_object保留但arm_states被清空，内部状态矛盾。真实Web目前可能先被R1挡住，不能据此宣称此边界安全。

另有：

```python
try:
    snapshot = loader(candidate, change_kind="platform_rebind")
except TypeError:
    snapshot = loader(candidate)
```

它无法区分“不支持关键字参数”和“load内部写入后抛TypeError”。RB08模拟后者，观察到先platform_rebind、再scene_edit两次调用，最后状态还被标成synchronized。

**修复**：共用idle/holding/recovery检查；接口兼容在构造时或能力声明处完成，不捕获业务调用的广泛TypeError后重试。已尝试写入但结果不明时进入unknown/quarantine，通过同一transactionID核对回执和live digest，不重发第二次修改。

**回归**：持物、状态未知、执行中、暂停/关闭；load内部TypeError前/后写、HTTP超时/回执丢失；任何路径最多一次变更请求，未知结果保持锁。

### R7 / P1：能力判定仍是UR5e硬编码，而不是匹配Profile

**来源：S02 `_platform_execution_capability`。RB09。**

当前逻辑仅对ur5e_arm返回supported，而且“任意profile存在”就满足一部分条件；Piper/UR10始终unsupported。RB09的合成registry显示：Piper有自身profile仍unsupported，UR5e只有无关Piper profile反而supported。

这不是要求放开未注册机器人的规划。**OLS可展示 ≠ 已注册可规划 ≠ 实时状态已确认 ≠ 真实执行可用。** 即使当前只允许UR5e，也应以明确已验证配置表达，而非任意profile为真。

**修复**：按实际robot asset、driver/joint inventory、gripper、挂接、规划能力和profile唯一匹配；成功切换后清除旧绑定是对的，但必须完成新绑定/明确unknown，才能声称可规划。未注册平台保留unsupported。不得把“展示切换成功”报告成机器人执行成功。

### R8 / P1：首轮换臂后，Application可能把旧平台manifest写回

**来源：S05 `_handle`的robot_asset_switch bootstrap与report.scene_created分支。源码确认，尚未完整集成复现。**

首轮先初始化默认模板，再做rebind。rebind已经更新session.platform_object_ids；随后report.scene_created为true时，Application又用默认模板objects覆盖这个集合。如果新臂不需要旧底座，已删除底座ID会重新进入manifest，下一次校验可能失败。

**修复**：在最终候选已确认后只生成一次manifest；不得用旧template覆盖实际candidate。首轮创建+切换最好预构建最终候选再一次提交；至少明确失败恢复与original冻结时机。

**回归**：空session首句换到无底座平台，下一句查询/新增正常；manifest仅包含最终平台对象；失败不遗留半初始化状态。

### R9 / P1：上轮多子句方位广播问题仍在

**来源：S09 `_normalize_scene_edit_layout_output`。RB10。**

非桌面参照物已加保护，值得保留。但函数仍从整句话选一个region，再覆盖每个符合条件的桌面add：

```text
输入：在桌面左上角增加苹果，在桌面右下角增加香蕉
正确模型结果：left_front、right_back
归一化后：left_front、left_front
```

这是Python改坏正确模型结果，不是Qwen理解失败。

**修复**：只做语义不变的默认填充，保留已有合法明确区域；确需修复时按每个操作的原文子句/span对应，而不是全句广播。正反顺序、逗号/然后、同类不同位置都应覆盖。

### R10 / P1：可复现测试与验收尚缺闭环

**来源：S10、S12、CI证据。**

现有装配测试偏向“UR5e→Piper且用户同时指定gripper/camera”的正例，绕过AgentService状态机；camera-only只检查Transform与pedestal，没有检查driver；4项全部依赖开发机目录。故本轮所列边界没有被当前CI覆盖。

**修复**：将前述RB探针改写为仓库实际类的pytest回归，基础fixture不依赖真实OLS包；完整服务路由使用MockTransport和真实Session类。补充真实OLS1.0.8/浏览器验收，但与单元结果分开记录。

## 4. 本轮不应误报的点

- 平台资产能加载、展示，不代表Control/IK支持；未注册平台unsupported本身正确。
- 会话拒绝复用退役ID是保护正确，问题在新adapter的ID生成，不是应删除这个保护。
- 当前Gateway保留事务日志、CAS身份/摘要和回执检查，应该保留。缺陷位于上层状态机、允许的变更范围及重试边界，不能以“已有原子commit”证明整体正确。
- 部分旧缺陷已有修复，不能重复照抄旧报告：显式旧版本scene_edit响应已被更严格拒绝，asset key/name/selectable检查已经补上，普通物体reference已受保护。但缺省protocol响应仍有兼容早退，live边界仍建议按请求路径强制版本，而非按模型自报版本选择兼容策略。此为源码补充观察，未计入10项复现。
- 新adapter仅接受单arm场景，双臂进入robot_assembly_arm_ambiguous。当前限制需对外明确，不能把本次平台重绑定描述成通用双臂换装完成。

## 5. 推荐实施顺序

1. 先补失败回归，再统一Web/Session rebind入口与变更范围（R1、R5、R6）。
2. 修部分更新、末端重挂、候选索引和ID高水位（R2、R3、R4）。
3. 修首轮manifest与Profile判定（R7、R8），补多子句方位回归（R9）。
4. 修干净CI，独立环境构建wheel及smoke（R10）。
5. 最后做真实Qwen→Brain→Gateway→浏览器循环验收：只换相机、只换夹爪、换臂保持夹爪、往返切换、首轮切换、失败恢复、无关物体保持。继续保持executed=false，不调用Control。

所有阶段报告原始指令、解析结构、切换前后Scene与组件diff、身份/子版本/digest、transactionID、profile/capability判定依据。不能只用截图“看起来换了”作为通过条件。

## 6. 包内文件

- `implementation_review.md`：本审查。
- `codex_tasks.txt`：可复制的实施任务入口。
- `reproduce_isolated.py`：10项隔离缺陷行为探针。
- `isolated_results.json`：本次实际探针输出。
- `sources/`：复现所用方法摘录及必要typing/import；不是全仓。
- `sources_manifest.json`：来源、复现环境和文件摘要。
- `ci_evidence_summary.txt`：远端CI摘要及地址。

运行探针：Python3.11+与Pydantic2环境中执行`python reproduce_isolated.py`。本次实际执行环境为3.13.5；正式修复验收必须另在项目支持的3.11/3.12环境中运行实际仓库测试。

## 7. 固定提交源码索引
- **S01** `src/robot_agent_brain/adapters/ols_robot_assembly.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/adapters/ols_robot_assembly.py
- **S02** `src/robot_agent_brain/session/brain_session.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/session/brain_session.py
- **S03** `src/robot_agent_brain/web/service.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/web/service.py
- **S04** `src/robot_agent_brain/web/gateway.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/web/gateway.py
- **S05** `src/robot_agent_brain/application.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/application.py
- **S06** `src/robot_agent_brain/scene/component_reference_registry.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/scene/component_reference_registry.py
- **S07** `src/robot_agent_brain/scene/component_access.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/scene/component_access.py
- **S08** `src/robot_agent_brain/models/qwen_http.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/models/qwen_http.py
- **S09** `src/robot_agent_brain/models/task_understanding.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/src/robot_agent_brain/models/task_understanding.py
- **S10** `brain_tests/test_ols_robot_assembly.py`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/brain_tests/test_ols_robot_assembly.py
- **S11** `config/ols_1_0_8_manifest.json`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/config/ols_1_0_8_manifest.json
- **S12** `pyproject.toml`
  https://github.com/haotian2410/robot_agent_brain/blob/041516434bb34272c3d3b364cb001af2568ef7a4/pyproject.toml

CI运行：https://github.com/haotian2410/robot_agent_brain/actions/runs/42338432830
